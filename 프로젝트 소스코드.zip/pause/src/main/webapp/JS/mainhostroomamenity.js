$('.show1').hide(); //페이지를 로드할 때 표시할 요소

$('u').click(function(event) {
	
	if($(event.target).text().trim() === '수정') {
		$(event.target).text('취소');
		
		$(event.target).siblings('.show1').show();
		
	} else if($(event.target).text().trim() === '취소'){
		$(event.target).text('수정');
		
		$(event.target).siblings('.show1').hide();
		
	} else {
		// do nothing
	}
	
	console.log();
	
})

$(document).on("click", ".btn-success", function(event){
	
	let _url = "amenityupdate.do";
	let _data = {};
	
	// 데이터 담기
	_data["no"] = $('#host-room-no').val();
	$('.container2').children().each(function(index, item){
		
		$(item).children().each(function(index2, item2){
			
			if(item2.tagName === 'INPUT'){
			
				if(item2.checked) {
					_data[$(item2).prop("name")] = "1";
				} else {
					_data[$(item2).prop("name")] = "0";
				}
			}
		});
	});
	
	$.ajax({
		url: _url,
		type: "POST",
		data: _data,
		success: function(data) {
			
			if(data > 0) {
				alert("수정이 완료 되었습니다.");
			}else {
				alert("error");
			}
			
		}
	})
	
})