$('.show1').hide(); //페이지를 로드할 때 표시할 요소

$('u').click(function(event) {
	
	if($(event.target).text().trim() === '수정') {
		$(event.target).text('취소');
		
		$(event.target).siblings('.show1').show();
		
	} else if($(event.target).text().trim() === '취소'){
		$(event.target).text('수정');
		
		$(event.target).siblings('.show1').hide();
		
	} else {
		// do nothing
	}
	
	console.log();
	
})

$(document).on("click", '.btn-success', function(event){
	var target = $(event.target).siblings('.form-control');
	
	console.log(target.prop("name"));
	
	
	let name = target.prop("name");
	let value = target.val();
	
	if(name === "check_in" || name === "check_out") {
		if(!(value.match(/^\d{2}^\s:\d{2}^\s$/g))){
			alert("ex) 14:00 형식에 맞게 수정해주세요.");
			return;
		} 
	}
	
	let _url = "infomationupdate.do";
	let _data = {};
	
	_data["no"] = $('#host-room-no').val();
	_data[name] = value;
	
	console.log($(event.target).parent().parent());
	
	$.ajax({
	
		url: _url,
		data: _data,
		type: "POST",
		success: function(data) {
		
			if(data > 0) {
				alert("수정이 완료 되었습니다.");
				$(event.target).parent().parent().siblings('.syntax_1').text(value);
				$(event.target).parent('.show1').hide();
				
			}else {
				alert("error");
			}
				
		}
	
	});
	
})