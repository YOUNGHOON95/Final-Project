$(document).on("click", "#view-more", clickViewMoreButton);
		
let page = 1;
const pageSize = 6;

function clickViewMoreButton(event) {
	
	page++;
	
	let start = (page - 1) * pageSize + 1;
	let end = page * pageSize;
	
	$.ajax(
			{
				url: "moremainhostroomlist.do",
				type: "GET",
				data: {
					"start": start,
					"end": end
				},
				success: function(data){
					$.each(data, function(index, hostRoom){
						let div = "" +`<div class="col-lg-4 col-md-6">
											<div class="blog-item set-bg" data-setbg="blog/blog-1.jpg"
												style="background-color: skyblue;">
												<div class="bi-text">
													<h4>
														<a href="mainhostroominformation.do?no=${hostRoom.no}">${hostRoom.name}</a>
													</h4>
													<div class="b-time check_out">
														체크인 시간 <i class="icon_clock_alt"></i>${hostRoom.checkIn}
													</div>
													<div class="b-time check_in">
														체크아웃 시간 <i class="icon_clock_alt"></i>${hostRoom.checkOut }
													</div>
												</div>
											</div>
										</div>`;
										
						$('#startBookingCard').append(div);
					});
					
				},
				error: function (request, status, error){
					
				}
			}
	);

} 