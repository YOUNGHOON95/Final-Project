$(document).ready(function() {
	var wsocket;
	connect();
	$('#sendBtn').click(function() { send(); });
	
	function connect() {
		wsocket = new WebSocket("ws://"+location.host+"/bit/chat-ws");
		wsocket.onerror = function(event){
			console.log(event);
		}
		wsocket.onopen = onOpen;
		wsocket.onmessage = onMessage;
		wsocket.onclose = onClose;
	}
	function disconnect() {
		wsocket.close();
	}
	
	function onOpen(evt) {
		_data = {
			cmd: "login"
		};
		
		wsocket.send(JSON.stringify(_data));
	}
	
	function onMessage(evt) {
		var data = evt.data;
		setMessageNav(data);
		appendMessage(data);
	}
	
	function onClose(evt) {
		disconnect();
	}
	
	function send() {
		
		let cmd = "chat";
		
		let m_to = $('#to_user_name').val();
		
		let m_from = $('#from_user_name').val();
		
		let msg = $('#input-msg').val();
		
		let _booking_no = $('#booking_no').val();
		
		let _data = {
			cmd: cmd,
			to_user: m_to,
			from_user: m_from,
			msg: msg,
			booking_no: _booking_no
		};
		
		$('#input-msg').val("");
		
		wsocket.send(JSON.stringify(_data));
		
	}
	
	function appendMessage(msg) {
		
		let me = $('#from_user_name').val();
		let obj = JSON.parse(msg);
		
		if(obj.from_user === me) {
			// do nothing
		} else {
			viewAlert(obj.count);
		}
		
		if(obj.msg == null) {
			return;
		}
		
		console.log(obj);
		
		
		let booking_no = $('#booking_no').val();
		console.log(me + " / " + booking_no);
		
		if(booking_no == null){
			return;
		}
		
		let div = "" + ``;
		
		if(me === obj.from_user) {
			div += `<div class="container darker">
						<p align="right">${obj.msg}</p>
						<span class="time-right">${obj.write_date}</span>
					</div>`;
		}
		else {
			div += `<div class="container">
						<p>${obj.msg}</p>
						<span class="time-left">${obj.write_date}</span>
					</div>`;
		}
		
		$('#div-chat').append(div);
		
		cursorToButton();
		
		
		if(me != null && booking_no == obj.booking_no) {
		
			let event;
			
			document.querySelectorAll('#div-chat-nav').forEach(element => {
			
				if(element.querySelector('#select_booking_no').value === booking_no) {
					event = element.querySelector('#select_booking_no');
				}
			
			})
			
			console.log(event);
			console.log($(event).parents('#chat-room'));
			
			alreadyInChatRoom($(event).parents('#chat-room'));
			
			$.ajax({
			
				url: "updatemessageconfirm.do",
				data: {
					from_user: me,
					booking_no: booking_no
				},
				type: "POST",
				success: function(data) {
					if(data > 0) {
						console.log("success");
						
					} else {
						console.log("fail");
					}
					
				} // success end
			
			}) // ajax end
			
		} // if end
		
	} // append message end
	
	function setMessageNav(msg) {
	
		$.ajax({
		
			url: "getMessageNav.do",
			type: "GET",
			async: false,
			success: function(data) {
			
				$('#div-chat-nav').empty();
				
				$.each(data, function(index, map) {
					
					let div = "";
					
					div += `<div class="single-comment-item second-comment" id="chat-room" style="cursor: pointer;">
			                   <div class="sc-author">
			                       <img src="upload/${map.TO_USER_PROFILE_IMG}" onerror="this.src='assets/defaultProfileImg.svg'">
			                   </div>
			                   <div class="sc-text">
			                       <span>${map.NAV_CHECK_IN } ~ ${map.NAV_CHECK_OUT } </span>
			                       <h5>${map.TO_USER_NAME }</h5>
			                       <p id="card-check">안 읽은 메시지 ${map.DEPART_CHECK } 건</p>
			                   </div>
			                   
			                   <input type="hidden" value="${map.TO_USER_TAGNUMBER }" id="select_to_user_name">
						  	   <input type="hidden" value="${map.BOOKING_NO }" id="select_booking_no">
			                   
			               </div>`;
					
					$('#div-chat-nav').append(div);
				
				})
			}
		
		})
	
	}
	
	
	
	$(document).on("click", ".profile", function(){
		location.href = "mainmessage.do";
	})
	
	$(document).on("click", "#button-msg", send);
	
	$(document).on("keypress", "#input-msg", function(event) {
		if(event.keyCode==13) {
			send();
		}
	});
	
	function alreadyInChatRoom(target) {
		
		
		let check = target.children('.sc-text').children('#card-check');
		let checkValue = check.text().replace("안 읽은 메시지 ", "").replace(" 건", "");
		
		console.log("checkValue : " + checkValue);
		
		let count = $('#alertArea').text() - checkValue;
		
		viewAlert(count);
		
		check.text("안 읽은 메시지 0 건");
	}
	
	
	$(document).on("click", "#chat-room", function(event) {
	
		let target = $(event.target).parents('#chat-room');
		
		console.log(target);
		
		let _from_user = $('#from_user_name').val();
		let _to_user = target.children('#select_to_user_name').val();
		let _booking_no = target.children('#select_booking_no').val();
		
		console.log(_from_user + " / " + _to_user + " / " + _booking_no);
		
		let _url = "loadchatmessage.do"
		let _data = {
			from_user: _from_user,
			to_user: _to_user,
			booking_no: _booking_no
		};
		
		$.ajax({
			url: _url,
			type: "GET",
			data: _data,
			async : false,
			success: function(data) {
				
				console.log(data);
				
				let chatRoom = $('#div-chat');
				
				alreadyInChatRoom(target);
				
				let me = $('#from_user_name').val();
				let opponent = $('chat.to_user').val();
				
				chatRoom.empty();
				
				let div = "<h2>⌨채팅 문의⌨</h2>";
				div += `<div class="rd-reviews"></div>`;
				
				div += `<input type="hidden" id="booking_no" value="${_booking_no}">`;
				div += `<input type="hidden" id="to_user_name" value="${_to_user}">`;
				
				$.each(data, function(index, item){
					
					if(me === item.from_user) {
						div += `<div class="container darker">
									<p align="right">${item.msg}</p>
									<span class="time-right">${item.write_date}</span>
								</div>`;
					}
					else {
						div += `<div class="container">
									<p>${item.msg}</p>
									<span class="time-left">${item.write_date}</span>
								</div>`;
					}
					
					
				});
				
				chatRoom.append(div);
				
				
				cursorToButton();	
				
			}
		})
		
		let url = "loaddetail.do";
		let data = {
			booking_no: _booking_no
		}
		
		$('#div-detail').empty();
		
		$.ajax({
			url: url,
			type: "GET",
			data: data,
			success: function(data){
				let div = "" + ``;
				
				div += `<div class="row">
							<h2>여행 세부 정보</h2>
						</div>
						<div class="rd-reviews"></div>
						
						<div class="room-details-item">
				            <div class="rd-text">
				                <div class="rd-title">
				                    <h3>${data.HOST_ROOM_NAME}</h3>
				                    <div class="rdt-right">
				                        ${data.HOST_ROOM_ZIP_CODE} ${data.HOST_ROOM_ADDR} ${data.HOST_ROOM_ADDR_DETAIL}
				                    </div>
				                </div>
				                <!-- <h2>159$<span>/Pernight</span></h2> -->
				                <table>
				                    <tbody>
				                        <tr>
				                            <td class="r-o">호스트:</td>
				                            <td>${data.HOST_NAME}</td>
				                        </tr>
				                        <tr>
				                            <td class="r-o">체크인:</td>
				                            <td>${data.DETAIL_CHECK_IN}</td>
				                        </tr>
				                        <tr>
				                            <td class="r-o">체크아웃:</td>
				                            <td>${data.DETAIL_CHECK_OUT}</td>
				                        </tr>
				                        <tr>
				                            <td class="r-o">게스트:</td>
				                            <td>${data.RESERVATION_CAPACITY}명</td>
				                        </tr>
				                    </tbody>
				                </table>
				                
				                <div class="rd-reviews">
				                	<h4>결제 내역</h4>
				                </div>
				                
				                <table>
				                    <tbody>
				                        <tr>
				                            <td class="r-o">₩${data.COST} x ${data.NIGHT}박:</td>
				                            <td>${data.PAY}</td>
				                        </tr>
				                        
				                        <tr>
				                            <td class="r-o">
					                            <div class="rd-reviews">
								                	<h4>총합계</h4>
								                </div>
							                </td>
				                            <td><h4>${data.PAY}</h4></td>
				                        </tr>
				                        
				                    </tbody>
				                </table>
				                
				                
				                
			                </div>`;
						
				$('#div-detail').append(div);
				
			}
		})
		
	});
	
	function cursorToButton() {
		var offset = $('#input-msg').offset();
		
		var chatChildren = document.querySelector('#div-chat').childNodes;
		
		if(chatChildren == null) {
			return;
		}
		
		chatChildren[chatChildren.length - 1].scrollIntoView();
	}
	
	function viewAlert(count) {
		$("#alertArea").removeClass("alert");
		$('#alertArea').empty();
		
		if(count > 0) {
			$("#alertArea").addClass("alert");
			$('#alertArea').text(count);	
		}
	}
	
})