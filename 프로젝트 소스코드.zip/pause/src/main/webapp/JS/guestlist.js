/**
 * 
 */
     window.onload = function() {
     
     
     
     
 	searchCard();
 
};
let search = {
		capacity : localStorage.getItem('capacity'),
		check_in : localStorage.getItem('check_in'),
		check_out : localStorage.getItem('check_out'),
		addr : localStorage.getItem('addr')
}
console.log(search);

let searchCard = () => {
	$.ajax({
		type : "GET",
		url : "searchCard.do",
		data : search,
		dataType :  "json",
		success : (data) => {
			
			console.log(data);
			
			$('#searchcard_section').empty();
			for(let i = 0; i < data.length; i++){
				str += '<div class="col-lg-3 col-md-6">'
					+ '<div class="hp-room-item set-bg" data-setbg="assets/img/room/room-b1.jpg" style="background-image: url(' + 'upload/' + data[i].file1 +');">'
					+ '<div class="hr-text">'
					+ '<h3>' + data[i].name + '</h3>'
					+ '<h2>' + data[i].cost + '<span>/박</span></h2>'
					+ '<table>'
					+ '<tbody>'
					+ '<tr>'
					+ '<td class="r-o">평점:</td>'
					+ '<td>'+data[i].total_avg+' 점</td>'
					+ '</tr>'
					+ '<tr>'
					+ '<td class="r-o">총 인원수:</td>'
					+ '<td>' + data[i].capacity + ' 명</td>'
					+ '</tr>'
					+ '<tr>'
					+ '<td class="r-o">침대 수:</td>'
					+ '<td>'+ data[i].count_bed+' 개</td>'
					+ '</tr>'
					+ '<tr>'
					+ '<td class="r-o">후기:</td>'
					+ '<td>'+ data[i].cnt +'개</td>'
					+ '</tr>'
					+ '</tbody>'
					+ '</table>'
					+ '<a href="detailpage.do?no=' + data[i].no + '" class="primary-btn">More Details</a>'
					+ '</div>'
					+ '</div>'
					+ '</div>'

			};
			$('#searchcard_section').append(str);
			str = "";
		},
		error : (request,status,error) => {
			alert("실패다 임마");
			console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
		}
		
	})
}

	//필터
	let fil = {
			"kitchen":0,
			"laundry":0,
			"wifi":0,
			"count_bed":1,
			"airconditioner":0,
			"free_parking":0,
			"bbq_grill":0,
			"shower_supplies":0,
			"cooking_item":0,
			"tv":0,
			"ott":0,
			"available_smoking":0,
			"available_pet":0,
			"min":0,
			"max":999999,
			"addr":localStorage.getItem('addr'),
			"capacity":localStorage.getItem('capacity'),
			"check_in":localStorage.getItem('check_in'),
			"check_out":localStorage.getItem('check_out')
	}
	
	//침대 갯수 초기화
	let bedNum = 1;
	
	//욕실 갯수 초기화
	let bathNum = 1;
	
	//필터 적용한 숙소검색결과 문자열 저장
	let str = "";
	//////////////////////////////////////////////
	
	let min_cost = document.getElementById('min').value;
	let max_cost = document.getElementById('max').value;
	
	//최소 가격 체크
	let check_min = () => {
		min_cost = document.getElementById('min').value;
		console.log(min_cost);
		let check_num = /^[0-9]*$/;
		if(!min_cost.match(check_num)){
			alert("숫자만 입력해 주세요");
		}else if(min_cost == null || min_cost == ""){
			alert("빈칸을 채워 주세요");
		}else{
			fil.min = min_cost;
		}
	}
	
	let check_max = () => {
		max_cost = document.getElementById('max').value;
		console.log(max_cost);
		let check_num = /^[0-9]*$/;
		console.log(max_cost);
		if(!max_cost.match(check_num)){
			alert("숫자만 입력해 주세요");
		}else if(max_cost == null || max_cost == ""){
			alert("빈칸을 채워 주세요");
		}else{
			fil.max = max_cost;
		}
		
		if(fil.min > fil.max){
			min_cost = document.getElementById()
		}
	}
	//주방 체크
	let kitchen = document.getElementById('kitchen');
	let check_kit = () => {
		if(kitchen.checked ==true){
			fil.kitchen = kitchen.value;
		}else{
			fil.kitchen = 0;
		}
	}
	//세탁기 체크
	let laundry = document.getElementById('laundry');
	let check_lau = () => {
		if(laundry.checked == true){
			fil.laundry = laundry.value;
		}else{
			fil.laundry = 0;
		}
	}
	//와이파이 체크
	let wifi = document.getElementById('wifi');
	let check_wifi = () => {
		if(wifi.checked == true){
			fil.wifi = wifi.value;
		}else{
			fil.wifi = 0;
		}
	}
	//에어컨 체크
	let airconditioner = document.getElementById('airconditioner');
	let check_AC = () => {
		if(airconditioner.checked == true){
			fil.airconditioner = airconditioner.value;
			console.log(fil.airconditioner);
		}else{
			fil.airconditioner = 0;
		}
	}
	
	
	//무료주차 체크
	let free_parking = document.getElementById('free_parking');
	let check_free = () => {
		if(free_parking.checked == true){
			fil.free_parking = free_parking.value;
		}else{
			fil.free_parking = 0;
		}
	}
	//바베큐 체크
	let bbq_grill = document.getElementById('bbq_grill');
	let check_bbq = () => {
		if(bbq_grill.checked == true){
			fil.bbq_grill = bbq_grill.value;
		}else{
			fil.bbq_grill = 0;
		}
	}
	
	
	//침실 갯수 정하기
	let count_bed = document.getElementById('count_bed');
	count_bed.innerHTML = bedNum;
	//침실 갯수 [-]
	let bed_minus = () => {
		--bedNum;
		if(bedNum < 1){
			bedNum = 1;
			count_bed.innerHTML = bedNum;
			fil.count_bed = bedNum;
		}else{
			count_bed.innerHTML = bedNum;
			fil.count_bed = bedNum;
		}
	}
	//침실 갯수 [+]
	let bed_pluse = () => {
		++bedNum;
		if(bedNum >= 15){
			bedNum = 14;
			count_bed.innerHTML = bedNum;
			fil.count_bed = bedNum;
			console.log(fil.count_bed);
		}else{
			count_bed.innerHTML = bedNum;
			fil.count_bed = bedNum;
			console.log(fil.count_bed);
		}
	}
	
	
	//샤워용품 체크
	let shower_supplies = document.getElementById('shower_supplies');
	let check_sup = () => {
		if(shower_supplies.checked == true){
			fil.shower_supplies = shower_supplies.value;
		}else{
			fil.shower_supplies = 0;
		}
	}
	//주방용품 체크
	let cooking_item = document.getElementById('cooking_item');
	let check_cook = () => {
		if(cooking_item.checked == true){
			fil.cooking_item = cooking_item.value;
		}else{
			fil.cooking_item = 0;
		}
	}
	//TV 체크
	let TV = document.getElementById('TV');
	let check_TV = () => {
		if(TV.checked == true){
			fil.tv = TV.value;
		}else{
			fil.tv = 0;
		}
	}
	//OTT 체크
	let OTT = document.getElementById('OTT');
	let check_OTT = () => {
		if(OTT.checked == true){
			fil.ott = OTT.value;
		}else{
			fil.ott = 0;
		}
	}
	//흡연 가능 여부 체크
	let available_smoking = document.getElementById('available_smoking');
	let check_smoking = () => {
		if(available_smoking.checked == true){
			fil.available_smoking = available_smoking.value;
		}else{
			fil.available_smoking = 0;
		}
	}
	//애완동물 동반 가능 여부 체크 
	let available_pet = document.getElementById('available_pet');
	let check_pet = () => {
		if(available_pet.checked == true){
			fil.available_pet = available_pet.value;
		}else{
			fil.available_pet = 0;
		}
	}
	
	let check_fil = function(){
		check_kit();
		check_lau();
		check_wifi();
		check_AC();
		check_free();
		check_bbq();
		check_sup();
		check_cook();
		check_TV();
		check_OTT();
		check_smoking();
		check_pet();
		check_min();
		check_max();
		console.log(fil);
		$.ajax(
			{
				type : 'GET',
				url  :'filter.do',
				data : fil,
				dataType : 'json',
				success : (data) => {
					console.log(data);
					$('#searchcard_section').empty();
					alert('성공');
					for(let i = 0; i < data.length; i++){
						str += '<div class="col-lg-3 col-md-6">'
							+ '<div class="hp-room-item set-bg" data-setbg="assets/img/room/room-b1.jpg" style="background-image: url(' + 'upload/' + data[i].file1 +');">'
							+ '<div class="hr-text">'
							+ '<h3>' + data[i].name + '</h3>'
							+ '<h2>' + data[i].cost + '<span>/박</span></h2>'
							+ '<table>'
							+ '<tbody>'
							+ '<tr>'
							+ '<td class="r-o">평점:</td>'
							+ '<td>'+data[i].total_avg+' 점</td>'
							+ '</tr>'
							+ '<tr>'
							+ '<td class="r-o">총 인원수:</td>'
							+ '<td>' + data[i].capacity + ' 명</td>'
							+ '</tr>'
							+ '<tr>'
							+ '<td class="r-o">침대 수:</td>'
							+ '<td>'+ data[i].count_bed+' 개</td>'
							+ '</tr>'
							+ '<tr>'
							+ '<td class="r-o">후기:</td>'
							+ '<td>'+ data[i].cnt +'개</td>'
							+ '</tr>'
							+ '</tbody>'
							+ '</table>'
							+ '<a href="detailpage.do?no=' + data[i].no + '" class="primary-btn">More Details</a>'
							+ '</div>'
							+ '</div>'
							+ '</div>';
						
					};
					$('#searchcard_section').append(str);
					str = "";
				},
				error : function(request,status,error){
					console.log("code:"+request.status+"\n"+"message:"+request.responseText+"\n"+"error:"+error);
					alert("error: 실패다 임마");
				}
			}
		)
	}
	let open_filter_modal = () => {
		document.querySelector('.modal-filter').style.display ='block';
		document.querySelector('body').style.overflow = 'hidden';
	    document.querySelector('body').style.hight = '100%';
	}
	let close_filter_modal = () => {
		document.querySelector('.modal-filter').style.display ='none';
		document.querySelector('body').style.overflow = 'auto';
	    document.querySelector('body').style.hight = '100%';
	}
	document.getElementById('show-filter-modal').onclick = open_filter_modal;
	document.getElementById('modal-filter-close').onclick = close_filter_modal;
	
	console.log(check_fil);
	document.getElementById("filttering").onclick = check_fil;
	document.getElementById('bed_minus_btn').onclick = bed_minus;
	document.getElementById('bed_pluse_btn').onclick = bed_pluse;
