$(document).ready(function() {
	var wsocket;
	connect();
	$('#sendBtn').click(function() { send(); });
	
	function connect() {
		wsocket = new WebSocket("ws://"+location.host+"/bit/chat-ws");
		wsocket.onerror = function(event){
			console.log(event);
		}
		wsocket.onopen = onOpen;
		wsocket.onmessage = onMessage;
		wsocket.onclose = onClose;
	}
	function disconnect() {
		wsocket.close();
	}
	
	function onOpen(evt) {
		console.log("onOpen(evt)");
	}
	
	function onMessage(evt) {
		console.log("evt :" + evt);
		var data = evt.data;
		appendMessage(data);
	}
	
	function onClose(evt) {
	}
	
	function send() {
		
		let cmd = "chat";
		
		let m_to = $('#to_user_name').val();
		
		let m_from = $('#from_user_name').val();
		
		let msg = $('#input-msg').val();
		
		let _booking_no = $('#booking_no').val();
		
		let _data = {
			cmd: cmd,
			to_user: m_to,
			from_user: m_from,
			msg: msg,
			booking_no: _booking_no
		};
		
		console.log(JSON.stringify(_data));
		
		wsocket.send(JSON.stringify(_data));
	}

	function appendMessage(msg) {
		console.log(msg);
		
		let me = $('#from_user_name').val();
		let div = "" + ``;
		let data = JSON.parse(msg);
		console.log(data);
		
		if(me === data.from_user) {
			div += `<div class="container darker">
						<p align="right">${data.msg}</p>
						<span class="time-right">${data.write_date}</span>
					</div>`;
		}
		else {
			div += `<div class="container">
						<p>${data.msg}</p>
						<span class="time-left">${data.write_date}</span>
					</div>`;
		}
		
		$('#div-chat').append(div);
		
		$('#input-msg').val("");
		$('#input-msg').focus();
		
		cursorToButton();
		
	}
	
	$(document).on("click", "#button-msg", send);
	
	$(document).on("keypress", "#input-msg", function(event) {
		if(event.keyCode==13) {
			send();
		}
	});
	
	
})


$(document).on("click", "#chat-room", function(event) {
	
	let target = $(event.target).parents('#chat-room');
	
	let _from_user = $('#from_user_name').val();
	let _to_user = target.siblings('#select_to_user_name').val();
	let _booking_no = target.siblings('#select_booking_no').val();
	
	let _url = "loadchatmessage.do"
	let _data = {
		from_user: _from_user,
		to_user: _to_user,
		booking_no: _booking_no
	};
	
	$.ajax({
		url: _url,
		type: "GET",
		data: _data,
		success: function(data) {
			
			console.log(data);
			
			let chatRoom = $('#div-chat');
			
			let me = $('#from_user_name').val();
			let opponent = $('chat.to_user').val();
			
			chatRoom.empty();
			
			let div = "<h2>⌨채팅 문의⌨</h2>";
			
			div += `<input type="hidden" id="booking_no" value="${_booking_no}">`;
			div += `<input type="hidden" id="to_user_name" value="${_to_user}">`;
			
			$.each(data, function(index, item){
				
				if(me === item.from_user) {
					div += `<div class="container darker">
								<p align="right">${item.msg}</p>
								<span class="time-right">${item.write_date}</span>
							</div>`;
				}
				else {
					div += `<div class="container">
								<p>${item.msg}</p>
								<span class="time-left">${item.write_date}</span>
							</div>`;
				}
				
				
			});
			
			chatRoom.append(div);
			
			
			cursorToButton();	
			
		}
	})
	
	let url = "loaddetail.do";
	let data = {
		booking_no: _booking_no
	}
	
	$('#div-detail').empty();
	
	$.ajax({
		url: url,
		type: "GET",
		data: data,
		success: function(data){
			let div = "" + ``;
			
			div += `<div class="row">
						<h2>여행 세부 정보</h2>
					</div>
					
					<div class="row">
						<div class="space">
							<div class="under-line"></div>
						</div>
					</div>
					
					<div class="row">
						<h6 class="display-9 font-weight-bold">${data.HOST_ROOM_NAME}</h6>
					</div>
					
					<div class="row">
						<h6 class="display-9">${data.HOST_ROOM_ZIP_CODE} ${data.HOST_ROOM_ADDR} ${data.HOST_ROOM_ADDR_DETAIL}</h6>
					</div>
					
					<div class="row">
						<div class="space">
							<div class="under-line"></div>
						</div>
					</div>
					
					<div class="row">
						<div class="col-8">호스트:${data.HOST_NAME}</div>
						<div class="col-4">
							<img src="/bit/upload/${data.HOST_PROFILE_IMG}" class="card-img" alt="no image">
						</div>
					</div>
					
					<div class="row">
						<div class="space">
							<div class="under-line"></div>
						</div>
					</div>
					
					<div class="row">
						<div class="col">체크인</div>
						<div class="col">${data.DETAIL_CHECK_IN}</div>
					</div>
					
					<div class="row">
						<div class="space">
							<div class="under-line"></div>
						</div>
					</div>
					
					<div class="row">
						<div class="col">체크아웃</div>
						<div class="col">${data.DETAIL_CHECK_OUT}</div>
					</div>
					
					<div class="row">
						<div class="space">
							<div class="under-line"></div>
						</div>
					</div>
					
					<div class="row">
						<div class="col">게스트</div>
						<div class="col">${data.RESERVATION_CAPACITY}명</div>
					</div>
					
					<div class="row">
						<div class="space">
							<div class="under-line"></div>
						</div>
					</div>
					
					<div class="row">
						<h2>결제 내역</h2>
					</div>
					
					<div class="row">
						<div class="space">
							<div class="under-line"></div>
						</div>
					</div>
					
					<div class="row">
						<div class="col">₩${data.COST} x ${data.NIGHT}</div>
						<div class="col">${data.PAY}</div>
					</div>
					
					<div class="row">
						<div class="space">
							<div class="under-line"></div>
						</div>
					</div>
					
					<div class="row">
						<div class="col font-weight-bold">총합계</div>
						<div class="col font-weight-bold">${data.PAY}</div>
					</div>`;
					
			$('#div-detail').append(div);
			
		}
	})
	
});


function cursorToButton() {
	var offset = $('#input-msg').offset();
    $('html').animate({scrollTop : offset.top}, 400);
}