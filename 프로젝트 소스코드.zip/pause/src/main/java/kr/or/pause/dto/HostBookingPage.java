package kr.or.pause.dto;

import java.sql.Date;

// 호스트쪽 승인 / 거절 페이지 뷰테이블 
public class HostBookingPage {
	private String booking_no;
	private int tagnumber;
	private int host_no; // 방 번호
	private String name;
	private String room_name;
	private Date check_in;
	private Date check_out;
	private String file1;
	private String status;
	private int host_number;// 호스트 번호
	private String email;
	private String rule;
	private int reservation_capacity;
	private int host_tagnumber;
	
	
	
	public int getHost_tagnumber() {
		return host_tagnumber;
	}
	public void setHost_tagnumber(int host_tagnumber) {
		this.host_tagnumber = host_tagnumber;
	}
	public int getReservation_capacity() {
		return reservation_capacity;
	}
	public void setReservation_capacity(int reservation_capacity) {
		this.reservation_capacity = reservation_capacity;
	}
	public String getRule() {
		return rule;
	}
	public void setRule(String rule) {
		this.rule = rule;
	}
	public String getBooking_no() {
		return booking_no;
	}
	public void setBooking_no(String booking_no) {
		this.booking_no = booking_no;
	}
	public int getTagnumber() {
		return tagnumber;
	}
	public void setTagnumber(int tagnumber) {
		this.tagnumber = tagnumber;
	}
	public int getHost_no() {
		return host_no;
	}
	public void setHost_no(int host_no) {
		this.host_no = host_no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRoom_name() {
		return room_name;
	}
	public void setRoom_name(String room_name) {
		this.room_name = room_name;
	}
	public Date getCheck_in() {
		return check_in;
	}
	public void setCheck_in(Date check_in) {
		this.check_in = check_in;
	}
	public Date getCheck_out() {
		return check_out;
	}
	public void setCheck_out(Date check_out) {
		this.check_out = check_out;
	}
	public String getFile1() {
		return file1;
	}
	public void setFile1(String file1) {
		this.file1 = file1;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getHost_number() {
		return host_number;
	}
	public void setHost_number(int host_number) {
		this.host_number = host_number;
	}
	
	
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "HostReviewPage [booking_no=" + booking_no + ", tagnumber=" + tagnumber + ", host_no=" + host_no
				+ ", name=" + name + ", room_name=" + room_name + ", check_in=" + check_in + ", check_out=" + check_out
				+ ", file1=" + file1 + ", status=" + status + ", host_number=" + host_number + "]";
	}
	
	
	
}
