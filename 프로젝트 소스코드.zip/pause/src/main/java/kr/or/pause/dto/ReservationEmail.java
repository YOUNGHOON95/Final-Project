package kr.or.pause.dto;

public class ReservationEmail {

	private String senderName; // 발신자 이름
	private String senderMail; // 발신자 이메일 주소
	private String receiveMail; // 수신자 이메일 주소
	private String subject; // 제목
	private String message; // 본문
	
	
	public ReservationEmail() {}
	
	
	public ReservationEmail( String receiveMail,  String message) {
		super();
		this.senderName = "잠시, 쉼 ";
		this.senderMail = "rlaeodjq681@gmail.com";
		this.receiveMail = receiveMail;
		this.subject = "예약 승인 알림 입니다.";
		this.message = message;
	}
	public String getSenderName() {
		return senderName;
	}
	public void setSenderName(String senderName) {
		this.senderName = senderName;
	}
	public String getSenderMail() {
		return senderMail;
	}
	public void setSenderMail(String senderMail) {
		this.senderMail = senderMail;
	}
	public String getReceiveMail() {
		return receiveMail;
	}
	public void setReceiveMail(String receiveMail) {
		this.receiveMail = receiveMail;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	@Override
	public String toString() {
		return "ReservationEmail [senderName=" + senderName + ", senderMail=" + senderMail + ", receiveMail="
				+ receiveMail + ", subject=" + subject + ", message=" + message + "]";
	}
	
	

}
