package kr.or.pause.guest.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.or.pause.dto.BookingInsert;
import kr.or.pause.dto.DetailCusReview;
import kr.or.pause.dto.DetailPage;
import kr.or.pause.dto.ReservationCard;
import kr.or.pause.dto.SearchCard;
import kr.or.pause.dto.SearchCardAjax;
import kr.or.pause.dto.SearchFilter;
import kr.or.pause.guest.dao.GuestDao;

@Service
public class GuestService {
	
	@Autowired
	private SqlSession sqlsession;
	
	public List<SearchCard> getSearchCard(int capacity, String addr, String check_in, String check_out) throws ClassNotFoundException, SQLException{
		
		List<SearchCard> list = new ArrayList<SearchCard>();
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		list = guestDao.getSearchCard(capacity, addr, check_in, check_out);
		
		return list;
	}
	
	public List<SearchCard> getSeachCardByFilter(SearchFilter searchfilter) throws ClassNotFoundException, SQLException{
		
		List<SearchCard> list = new ArrayList<SearchCard>();
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		list = guestDao.getSearchCardByFilter(searchfilter);
		
		return list;
	}
	
	public DetailPage getPageDetail(int no) throws ClassNotFoundException, SQLException {
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		DetailPage detailpage = null;
		detailpage = guestDao.getDetailPage(no);
		
		return detailpage;
	}
	
	public int getTagnumByPhonenum(String phone_number) throws ClassNotFoundException, SQLException {
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		int tagnumber = guestDao.getTagnumber(phone_number);
		
		return tagnumber;
	}
	
	public List<DetailCusReview> getCusReviews(int no) throws ClassNotFoundException, SQLException{
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		List<DetailCusReview> list = new ArrayList<DetailCusReview>();
		list = guestDao.getCusReview(no);
		
		return list;
	}
	
	public List<SearchCard> getSerachCardAjax(SearchCardAjax searchcard) throws ClassNotFoundException, SQLException{
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		List<SearchCard> list = new ArrayList<SearchCard>();
		list = guestDao.getSearchCardAjax(searchcard);
		
		return list;
	}
	
	public int insertBooking(BookingInsert booking) throws ClassNotFoundException, SQLException {
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		int result = guestDao.insertBooking(booking);
		
		return result;
	}
	
	public List<ReservationCard> getWatingReservationCard(int tagnumber) throws ClassNotFoundException, SQLException{
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		List<ReservationCard> list = new ArrayList<ReservationCard>();
		list = guestDao.getWatingReservationCard(tagnumber);
		
		return list;
	}
	
	public List<ReservationCard> getConfirmReservationCard(int tagnumber) throws ClassNotFoundException, SQLException{
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		List<ReservationCard> list = new ArrayList<ReservationCard>();
		list = guestDao.getConfirmReservationCard(tagnumber);
		
		return list;
	}
	
	public List<ReservationCard> getCompleteReservationCard(int tagnumber) throws ClassNotFoundException, SQLException{
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		List<ReservationCard> list = new ArrayList<ReservationCard>();
		list = guestDao.getCompleteReservationCard(tagnumber);
		
		return list;
	}
	
	public Map<String, Object> getMemberInfo(int tagnumber) throws ClassNotFoundException, SQLException{
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		Map<String, Object> map = new HashMap<String, Object>();
		map = guestDao.getMemberInfo(tagnumber);
		
		return map;
	}
	
	public int editMemberProfile_img(int tagnumber, String profile_img) throws ClassNotFoundException, SQLException {
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		int reslut = guestDao.editMemberProfile_img(tagnumber, profile_img);
		
		return reslut;
	}
	
	public int editMemberName(int tagnumber, String name) throws ClassNotFoundException, SQLException {
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		int result = guestDao.editMemberName(tagnumber, name);
		
		return result;
	}
	
	public int editMemberPassword(int tagnumber, String password) throws ClassNotFoundException, SQLException {
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		int result = guestDao.editMemberPassword(tagnumber, password);
		
		return result;
	}
	
	public int editMemberEmail(int tagnumber, String email) throws ClassNotFoundException, SQLException {
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		int result = guestDao.editMemberEmail(tagnumber, email);
		
		return result;
	}
	
	public int editMemberPhone_number(int tagnumber, String Phone_number) throws ClassNotFoundException, SQLException {
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		int result = guestDao.editMemberPhone(tagnumber, Phone_number);
		
		return result;
	}
	public Map<String, Object>getReservationData(int no) throws ClassNotFoundException, SQLException{
		
		GuestDao guestDao = sqlsession.getMapper(GuestDao.class);
		Map<String, Object> map = new HashMap<String, Object>();
		map = guestDao.getReservationData(no);
		
		return map;
	}
}


























