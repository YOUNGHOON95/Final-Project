package kr.or.pause.dto;
import java.sql.Date;

// 회원쪽 예약 내역 뷰 테이블
public class BookingView {
	private int booking_no;
	private int tagnumber;
	private int no;
	private String Name;
	private Date check_in;
	private Date check_out;
	private Date reservation_req_date;
	private String status;
	private String host_room_name;
	private int reservation_capacity;
	private String file1;
	private int cost;
	
	
	
	
	public int getReservation_capacity() {
		return reservation_capacity;
	}
	public void setReservation_capacity(int reservation_capacity) {
		this.reservation_capacity = reservation_capacity;
	}
	public int getCost() {
		return cost;
	}
	public void setCost(int cost) {
		this.cost = cost;
	}
	public int getBooking_no() {
		return booking_no;
	}
	public void setBooking_no(int booking_no) {
		this.booking_no = booking_no;
	}
	public int getTagnumber() {
		return tagnumber;
	}
	public void setTagnumber(int tagnumber) {
		this.tagnumber = tagnumber;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public Date getCheck_in() {
		return check_in;
	}
	public void setCheck_in(Date check_in) {
		this.check_in = check_in;
	}
	public Date getCheck_out() {
		return check_out;
	}
	public void setCheck_out(Date check_out) {
		this.check_out = check_out;
	}
	public Date getReservation_req_date() {
		return reservation_req_date;
	}
	public void setReservation_req_date(Date reservation_req_date) {
		this.reservation_req_date = reservation_req_date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getHost_room_name() {
		return host_room_name;
	}
	public void setHost_room_name(String host_room_name) {
		this.host_room_name = host_room_name;
	}
	public String getFile1() {
		return file1;
	}
	public void setFile1(String file1) {
		this.file1 = file1;
	}
	
	@Override
	public String toString() {
		return "BookingView [booking_no=" + booking_no + ", tagnumber=" + tagnumber + ", no=" + no + ", Name=" + Name
				+ ", check_in=" + check_in + ", check_out=" + check_out + ", reservation_req_date="
				+ reservation_req_date + ", status=" + status + ", host_room_name=" + host_room_name
				+ ", reservation_capacity=" + reservation_capacity + ", file1=" + file1 + ", cost=" + cost + "]";
	}
	
	
	
	
}
