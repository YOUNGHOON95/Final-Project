package kr.or.pause.guest.controller;

import java.security.Principal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import kr.or.pause.dto.BookingInsert;
import kr.or.pause.dto.DetailCusReview;
import kr.or.pause.dto.DetailPage;
import kr.or.pause.guest.service.GuestService;

@Controller
public class GuestController {

	@Autowired
	private GuestService guestservice;

	@RequestMapping(value = "hometo.do")
	public String testHome() {
		System.out.println("home.do");
		return "guest/search/test_main";
	}

	@RequestMapping(value = "search.do", method = RequestMethod.GET)
	public String getSearchCard()
			throws ClassNotFoundException, SQLException {
		return "guest/search/searchlist";
	}

	@RequestMapping(value = "detailpage.do", method = RequestMethod.GET)
	public String getPageDetail(int no, Model model) throws ClassNotFoundException, SQLException {

		DetailPage detailpage = guestservice.getPageDetail(no);
		List<DetailCusReview> list = new ArrayList<DetailCusReview>();
		list = guestservice.getCusReviews(no);
		
		model.addAttribute("detail", detailpage);
		model.addAttribute("review",list);
		
		
		return "guest/detailpage/detailpage";
	}

	
	@RequestMapping(value = "reservation.do", method = RequestMethod.POST)
	public String getReservationPage(int no, int capacity, String check_in, String check_out, int pay , int cost,Principal principal, Model model) throws ClassNotFoundException, SQLException{
		
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("capacity", capacity);
		map.put("no", no);
		map.put("check_in", check_in);
		map.put("check_out", check_out);
		map.put("pay", pay);
		map.put("cost",cost);
		
		int tagnumber = guestservice.getTagnumByPhonenum(principal.getName());
		Map<String, Object> map2 = new HashMap<String, Object>();
		
		map2 = guestservice.getReservationData(no);
		System.out.println(map2);
		model.addAttribute("tagnumber", tagnumber);
		model.addAttribute("book", map);
		model.addAttribute("data",map2);
		
		return "guest/reservation/reservationpage";
	}
	
	@RequestMapping(value = "booking.do", method = RequestMethod.POST)
	public String insertBooking(Principal principal, BookingInsert booking, Model model) throws ClassNotFoundException, SQLException {
		int result = guestservice.insertBooking(booking);
		System.out.println(principal);
		
		if(result > 0) {
			return "redirect:goreservation.do";
		}else {
			return "redirect:reservation.do";
		}
		
	}
	
	@RequestMapping(value = "guestedit.do")
	public String getGuestEditPage(Principal principal, Model model) throws ClassNotFoundException, SQLException {
		
		int tagnumber = guestservice.getTagnumByPhonenum(principal.getName());
		model.addAttribute("tagnumber", tagnumber);
		
		return "guest/edit/guesteditpage";
	}
	
}
























