package kr.or.pause.dto;

public class PauseHost {
	private int host_no;
	private int tagnumber;
	private String auth_identification; // 신분증 검사 여부 
	private String idetification_img; // 신분증 사진 명 
	private int income; // 수입 
	public int getHost_no() {
		return host_no;
	}
	public void setHost_no(int host_no) {
		this.host_no = host_no;
	}
	public int getTagnumber() {
		return tagnumber;
	}
	public void setTagnumber(int tagnumber) {
		this.tagnumber = tagnumber;
	}
	public String getAuth_identification() {
		return auth_identification;
	}
	public void setAuth_identification(String auth_identification) {
		this.auth_identification = auth_identification;
	}
	public String getIdetification_img() {
		return idetification_img;
	}
	public void setIdetification_img(String idetification_img) {
		this.idetification_img = idetification_img;
	}
	public int getIncome() {
		return income;
	}
	public void setIncome(int income) {
		this.income = income;
	}
	
	@Override
	public String toString() {
		return "PauseHost [host_no=" + host_no + ", tagnumber=" + tagnumber + ", auth_identification="
				+ auth_identification + ", idetification_img=" + idetification_img + ", income=" + income + "]";
	}
	
	
}
