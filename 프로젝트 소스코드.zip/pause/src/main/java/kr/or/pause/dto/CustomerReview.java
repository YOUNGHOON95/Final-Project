package kr.or.pause.dto;


import java.sql.Date;

public class CustomerReview {
	
	private int customer_review_no; // 리뷰 번호(시퀀스)
	private String write_date; // 작성일
	private int avg; // 평점
	private String content; // 작성 내용 
	private int tagnumber; // 태그 번호
	private int no; // 방번호
	private String writer; // 작성자
	private int booking_no;
	
	
	
	public CustomerReview() {};
	
	
	
	public int getBooking_no() {
		return booking_no;
	}



	public void setBooking_no(int booking_no) {
		this.booking_no = booking_no;
	}



	public int getCustomer_review_no() {
		return customer_review_no;
	}
	public void setCustomer_review_no(int customer_review_no) {
		this.customer_review_no = customer_review_no;
	}
	
	public String getWrite_date() {
		return write_date;
	}



	public void setWrite_date(String write_date) {
		this.write_date = write_date;
	}



	public int getAvg() {
		return avg;
	}
	public void setAvg(int avg) {
		this.avg = avg;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getTagnumber() {
		return tagnumber;
	}
	public void setTagnumber(int tagnumber) {
		this.tagnumber = tagnumber;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public String getWriter() {
		return writer;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	
	


	public CustomerReview(int customer_review_no, String write_date, int avg, String content, int tagnumber, int no,
			String writer, int booking_no) {
		super();
		this.customer_review_no = customer_review_no;
		this.write_date = write_date;
		this.avg = avg;
		this.content = content;
		this.tagnumber = tagnumber;
		this.no = no;
		this.writer = writer;
		this.booking_no = booking_no;
	}



	@Override
	public String toString() {
		return "CustomerReview [customer_review_no=" + customer_review_no + ", write_date=" + write_date + ", avg="
				+ avg + ", content=" + content + ", tagnumber=" + tagnumber + ", no=" + no + ", writer=" + writer + "]";
	}
	
	
	
}
