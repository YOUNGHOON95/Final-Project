package kr.or.pause.dto;

import lombok.Data;

@Data
public class BookingInsert {
	private String check_in;
	private String check_out;
	private int reservation_capacity;
	private int tagnumber;
	private int no;
	private int pay;
	
}
