package kr.or.pause.websocket;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import com.fasterxml.jackson.databind.ObjectMapper;

import kr.or.pause.dto.Chat;
import kr.or.pause.host.service.HostService;

@Configuration
public class WebSocketHandler extends TextWebSocketHandler {

	@Autowired
	private HostService service;

	private static Map<String, WebSocketSession> users = new HashMap<String, WebSocketSession>();

	private void log(String msg) {
		SimpleDateFormat simple = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String date = simple.format(new Date());
		System.out.println(date + " : " + msg);
	}

	// 연결
	@Override
	public void afterConnectionEstablished(WebSocketSession session) throws Exception {

		log(session.getPrincipal().getName() + " 접속");
		log(session.toString());
		
		String tagNumber = service.getTagNumber(session.getPrincipal().getName());
		
		users.put(tagNumber, session); // userid 와 session 저장
	}

	// 연결해제
	@Override
	public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
		if (session.getPrincipal() != null) {
			String tagNumber = service.getTagNumber(session.getPrincipal().getName());
			if (users.containsKey(tagNumber)) {
				users.remove(tagNumber); // 연결해제된 id 삭제
				log(session.getPrincipal().getName() + " 해제");
			}
		}
	}

	// 데이터 전송
	@Override
	protected void handleTextMessage(WebSocketSession session, TextMessage message) throws Exception {
		
		String msgstr = message.getPayload();
		JSONObject obj = (JSONObject) new JSONParser().parse(msgstr);
		
		String cmd = (String) obj.get("cmd");
		if(cmd.equals("login")) {
			String userid = service.getTagNumber(session.getPrincipal().getName());
			
			Chat chat = new Chat();
			chat.setTo_user(userid);
			
			int count = service.getCount(chat);

			chat.setCount(count);
			
			String jsonObject = new ObjectMapper().writeValueAsString(chat);
			
			if (users.containsKey(userid)) {
				TextMessage msg = new TextMessage(jsonObject);
				users.get(userid).sendMessage(msg);

				log("to_user : " + userid + " / " + jsonObject);
			}
		}
		
		else if(cmd.equals("chat")) {
			
			String to_user = (String) obj.get("to_user");
			String from_user = (String) obj.get("from_user");
			String msg = (String) obj.get("msg");
			int booking_no = Integer.parseInt((String)obj.get("booking_no"));
			
			Chat chat = new Chat();
			chat.setMsg(msg);
			chat.setTo_user(to_user);
			chat.setFrom_user(from_user);
			chat.setBooking_no(booking_no);
			chat.setWrite_date(new SimpleDateFormat("HH:mm").format(new Date()));
			
			int result = service.insertChat(chat);
			
			int count = service.getCount(chat);
			
			chat.setCount(count);
			
			if(result > 0) {
				String jsonObject = new ObjectMapper().writeValueAsString(chat);
				
				TextMessage textMessage = new TextMessage(jsonObject);
				
				
				users.get(from_user).sendMessage(textMessage);
				
				if(users.containsKey(to_user)) {
					users.get(to_user).sendMessage(textMessage);
				}
				
			} else {
				
				TextMessage textMessage = new TextMessage("{msg:'메시지 입력에 실패했습니다.'}");
				
				users.get(from_user).sendMessage(textMessage);
			}
		}
		
		
//		if (message.getPayload().equals("login") || message.getPayload().equals("view")) {
//			String userid = session.getPrincipal().getName();
//
//			int result = service.getmsgcount(userid);
//
//			if (users.containsKey(userid)) {
//				TextMessage msg = new TextMessage("수신된 쪽지 : " + result + "건");
//				users.get(userid).sendMessage(msg);
//
//				log(userid + " / " + message.getPayload() + " / " + msg.getPayload());
//			}
//		}
//
//		// 채팅방으로 입장
//		else if (message.getPayload().contains("chat")) {
//			
//			System.out.println(session.getPrincipal().getName());
//			System.out.println(session.getUri().getRawPath());
//			System.out.println(session.getUri().getPath());
//			
//			String chatMessage = message.getPayload().substring(4);
//			String[] chatMessageArr = chatMessage.split(",");
//
//			String toid = chatMessageArr[0];
//			String fromid = chatMessageArr[1];
//			String sendMessage = chatMessageArr[2];
//			
//			System.out.println(users.get(toid).getHandshakeHeaders().getLocation());
//
//			Message savemsg = new Message(toid, fromid, sendMessage);
//			service.insertMessage(savemsg);
//			int result = service.getmsgcount(fromid);
//
//			TextMessage msg = new TextMessage(toid + " : " + sendMessage);
//			users.get(fromid).sendMessage(msg);
//			users.get(toid).sendMessage(msg);
//			log(fromid + " / " + message.getPayload() + " / " + msg.getPayload());
//
//		}
//
//		else {
//			String fromid = message.getPayload().split(",")[1];
//
//			Message savemsg = new Message(message.getPayload().split(",")[0], message.getPayload().split(",")[1],
//					message.getPayload().split(",")[2]);
//			service.insertMessage(savemsg);
//
//			int result = service.getmsgcount(fromid);
//
//			if (users.containsKey(fromid)) {
//				TextMessage msg = new TextMessage("수신된 쪽지 : " + result + "건");
//				users.get(fromid).sendMessage(msg);
//				log(fromid + " / " + message.getPayload() + " / " + msg.getPayload());
//			}
//
//			System.out.println("fromid : " + fromid);
//			System.out.println(message.getPayload());
//		}

	}

	// 연결에 문제 발생시
	public void handleTransportError(WebSocketSession session, Throwable exception) throws Exception {
		log(session.getPrincipal().getName() + " / " + exception.getMessage());
	}

}
