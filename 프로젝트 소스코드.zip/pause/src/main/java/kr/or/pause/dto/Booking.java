package kr.or.pause.dto;


import java.sql.Date;
import lombok.Data;

@Data
public class Booking {
	private String booking_no;
	private int tagnumber;
	private int room_no;
	private String room_name;
	private String name;
	private Date check_in;
	private Date check_out;
	private String file1;
	private String status;
	private int host_no;


	public String getBooking_no() {
		return booking_no;
	}
	public void setBooking_no(String booking_no) {
		this.booking_no = booking_no;
	}
	public int getTagnumber() {
		return tagnumber;
	}
	public void setTagnumber(int tagnumber) {
		this.tagnumber = tagnumber;
	}
	public int getRoom_no() {
		return room_no;
	}
	public void setRoom_no(int room_no) {
		this.room_no = room_no;
	}
	public String getRoom_name() {
		return room_name;
	}
	public void setRoom_name(String room_name) {
		this.room_name = room_name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getCheck_in() {
		return check_in;
	}
	public void setCheck_in(Date check_in) {
		this.check_in = check_in;
	}
	public Date getCheck_out() {
		return check_out;
	}
	public void setCheck_out(Date check_out) {
		this.check_out = check_out;
	}
	public String getFile1() {
		return file1;
	}
	public void setFile1(String file1) {
		this.file1 = file1;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public int getHost_no() {
		return host_no;
	}
	public void setHost_no(int host_no) {
		this.host_no = host_no;
	}
	@Override
	public String toString() {
		return "Booking [booking_no=" + booking_no + ", tagnumber=" + tagnumber + ", room_no=" + room_no
				+ ", room_name=" + room_name + ", name=" + name + ", check_in=" + check_in + ", check_out=" + check_out
				+ ", file1=" + file1 + ", status=" + status + ", host_no=" + host_no + "]";
	}
	
	
}
