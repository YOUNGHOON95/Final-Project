package kr.or.pause.host.controller;

import java.security.Principal;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import kr.or.pause.commons.FileUtils;
import kr.or.pause.dto.Chat;
import kr.or.pause.dto.Host;
import kr.or.pause.dto.HostRoom;
import kr.or.pause.dto.PauseMember;
import kr.or.pause.host.service.HostService;
import kr.or.pause.login.service.JoinService;

@RestController
public class HostMainRestController {
	
	@Autowired
	HostService hostservice;
	
	@RequestMapping(value = "moremainhostroomlist.do", method = RequestMethod.GET)
	public List<HostRoom> mainhostroomlist(HttpServletRequest request, 
			@RequestParam(value="start", required = false) int start, 
			@RequestParam(value="end", required = false) int end) {
		
		Host host = (Host) request.getSession().getAttribute("host");
		
		List<HostRoom> hostRoomList = hostservice.selectListHostRoom(host, start, end);
		

		return hostRoomList;
	}
	
	@RequestMapping(value = "infomationupdate.do", method = RequestMethod.POST)
	public int infomationupdate(HostRoom hostRoom) throws ParseException {
		int result = 0;
		
		if(hostRoom.getCheckIn() != null) {
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
			Date parsedDate = (Date) dateFormat.parse("2021-06-29 " + hostRoom.getCheckIn() + ":00.000");
			Timestamp timestamp = new Timestamp(parsedDate.getTime());
			hostRoom.setCheck_in(timestamp);
		}
		
		if(hostRoom.getCheckOut() != null) {
			
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss.SSS");
			Date parsedDate = (Date) dateFormat.parse("2021-06-29 " + hostRoom.getCheckOut() + ":00.000");
			Timestamp timestamp = new Timestamp(parsedDate.getTime());
			hostRoom.setCheck_out(timestamp);
		}
		
		result = hostservice.updateHostRoomDynamic(hostRoom);
		
		return result;
	}
	
	@RequestMapping(value = "amenityupdate.do", method = RequestMethod.POST)
	public int amenityupdate(HostRoom hostRoom)  {
		int result = 0;
		
		result = hostservice.updateOptionAmenity(hostRoom);
		
		return result;
	}
	
	@RequestMapping(value = "pictureupdate.do", method = RequestMethod.POST)
	public int pictureupdate(HostRoom hostRoom, HttpServletRequest request) {
		int result = 0;
		
		Map<String, String> map = new HashMap<String, String>(); 
		
		int count = 0;
		
		for(MultipartFile file : hostRoom.getUpload_files()) {
			
			count++;
			
			if(file.getSize() > 0) {
				map.put("file" + count, FileUtils.saveFiles(file, request));
			} else {
				map.put("file" + count, "null");
			}
			
		}
		
		hostservice.updateFile2(map, hostRoom);
		
		return result;
	}
	
	@RequestMapping(value = "loadchatmessage.do", method = RequestMethod.GET)
	public List<Chat> loadchatmessage(Chat chat) {
		hostservice.updatemessageconfirm(chat);
		List<Chat> chatList = hostservice.getMessageInteract(chat);
		return chatList;
		
	}
	
	@RequestMapping(value = "loaddetail.do", method = RequestMethod.GET)
	public Map<String,String> loaddetail(Chat chat) {
		
		Map<String,String> chatList = hostservice.getDetail(chat);
		return chatList;
		
	}
	
	@RequestMapping(value = "updatemessageconfirm.do", method = RequestMethod.POST)
	public int updatemessageconfirm(Chat chat) {
		int result = 0;
		
		result = hostservice.updatemessageconfirm(chat);
		
		return result;
	}
	
	@Autowired
	private JoinService joinservice;
	
	@RequestMapping(value = "getMessageNav.do", method = RequestMethod.GET)
	public List<Map<String, String>> setMessageNav(Principal principal) {
		PauseMember pausemember = joinservice.getPauseMember(principal.getName()); 

		List<Map<String, String>> chatList = hostservice.getMessageNav(Integer.toString(pausemember.getTagnumber()));
		
		return chatList;
	}
	
	
	
	
}
