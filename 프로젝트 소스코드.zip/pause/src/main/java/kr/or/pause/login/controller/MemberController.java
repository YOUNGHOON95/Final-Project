package kr.or.pause.login.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;

import java.security.Principal;

import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.io.FileOutputStream;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.multipart.commons.CommonsMultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.or.pause.dto.BookingView;
import kr.or.pause.dto.CustomerReview;
import kr.or.pause.dto.MemberBooking;
import kr.or.pause.dto.PauseMember;
import kr.or.pause.login.service.JoinService;

@Controller

public class MemberController {
	

	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
	
	@Autowired
	private JoinService joinservice;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	// 수정 페이지 가기 위해 비밀번호 검증 
	@RequestMapping(value="memberconfirm.do",method=RequestMethod.POST)
	public String memberConfirm(@RequestParam("password") String password , Principal principal , Model model) {
		
		String view = "";
		
		
		// 회원정보 
		PauseMember pausemember = joinservice.getPauseMember(principal.getName());
		
		String encodedPassword = pausemember.getPassword();
		
		boolean result = bCryptPasswordEncoder.matches(password, encodedPassword);
		
		
		if(result) {
			view ="redirect:guestedit.do";
		} else {
			view ="redirect:main.do";
		}
		
		return view;
	}
	
	// 정보 수정 페이지 이동
	@RequestMapping(value="memberupdate.do", method=RequestMethod.GET)
	public String memberUpdate(Model model, Principal principal){
		PauseMember pausemember = joinservice.getPauseMember(principal.getName());
		model.addAttribute("member", pausemember);
		return "pause_update";
	}
	
	// 정보 수정 처리 
	@RequestMapping(value="/update.do")
	public String memberUpdate(@ModelAttribute PauseMember pausemember, HttpServletRequest request , Model model) {
		

		CommonsMultipartFile file = pausemember.getFile();
		String filename = file.getOriginalFilename();
		String path = request.getServletContext().getRealPath("/upload");
		String fpath = path + "\\" + filename;
		FileOutputStream fs  = null;
		
		pausemember.setProfile_img(filename);
		
		String password = request.getParameter("password");
		System.out.println(password);
		
//		pausemember.setPassword(this.bCryptPasswordEncoder.encode(password));
		
		try {
			fs = new FileOutputStream(fpath);
			fs.write(file.getBytes());
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				fs.close();
			} catch (Exception e2) {
				e2.printStackTrace();
			}
		}
		
		joinservice.updateName(pausemember);
		
		System.out.println(pausemember);

		model.addAttribute("newpausemember", pausemember);
		model.addAttribute("path", path);
		
		return "redirect:main.do";
	}
	
// 예약 조회 페이지로 이동
	@RequestMapping(value = "/goreservation.do" , method = RequestMethod.GET)
	public String goReservation(Model model,Principal principal) {
		PauseMember pausemember = joinservice.getPauseMember(principal.getName());		
		model.addAttribute("pausemember", pausemember);
		return "pause_reservation";
	}
	
	// 리뷰 쓰는 페이지로 이동 
		@RequestMapping(value = "/goreview.do")
		public String goReview(Model model , Principal principal,int no) {
			
			PauseMember pausemember = joinservice.getPauseMember(principal.getName());
			
			model.addAttribute("pausemember", pausemember);
			
			return "pause_review";
		}
		
		// 리뷰 작성(INSERT) 
					@RequestMapping(value ="/writereview.do" , method = RequestMethod.POST)
					public String insertReview(
											   @RequestParam("write_date") String write_date ,
											   @RequestParam("avg") int avg,
											   @RequestParam("content") String content ,
											   @RequestParam("tagnumber") int tagnumber ,
											   @RequestParam("no") int no ,
											   @RequestParam("booking_no") int booking_no,
											   @RequestParam("writer") String writer
											  ) {
											   
											
		CustomerReview customerreview = new CustomerReview(no, write_date, avg, content, tagnumber, no, writer, booking_no);
						System.out.println(booking_no);
						System.out.println(customerreview);
						try {
							
							joinservice.insertReview(customerreview);
							// 리뷰 쓰면 status 6 번으로 만드는 함수
							joinservice.updateReviewReservation(booking_no);
							System.out.println("업데이트 함수 실행");
							
						} catch (Exception e) {
							e.printStackTrace();
						}
						
						return "redirect:goreservation.do";
					}
			
		

	}


