package kr.or.pause.host.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import kr.or.pause.dto.HostReviewForHost;

public interface HostReviewForHostDao {
	
	public ArrayList<HostReviewForHost> getList(int host_no) throws ClassNotFoundException, SQLException;

	
}
