package kr.or.pause.login.service;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

import kr.or.pause.dto.CustomerReview;
import kr.or.pause.dto.MemberBooking;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import kr.or.pause.dto.PauseMember;
import kr.or.pause.login.JoinDao;

@Service
public class JoinService {
	
	
	private SqlSession sqlsession;
	
	@Autowired
	public void setSqlsession(SqlSession sqlsession) {
		this.sqlsession = sqlsession;
	}
	
	// 사이트 자체 회원가입
	public void insert(PauseMember pausemember) {
		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
		
		joindao.insert(pausemember);
	}
	
	// 휴대폰 번호 중복 체크
	public int phoneCheck(String phone_number) {
		
		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
		
		int result = joindao.phoneCheck(phone_number);
		
		return result;
	}
	
	// 회원 정보 불러오기 
	public PauseMember getPauseMember(String phone_number) {
		
		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
		
		PauseMember pausemember = joindao.getPauseMember(phone_number);
		
		return pausemember;
	}
	
	// 회원 수정 
	public void updateName(PauseMember member) {
		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
		
		 joindao.updateName(member);
		
		 System.out.println("서비스");
		
	}
	
//	// 회원 프로필 사진
//	public void updateImage(PauseMember member) {
//		
////		CommonsMultipartFile file = member.getFile();
////		
////		// DB에 들어갈 파일명
////		member.setProfile_img(file.getName());
////		
////		String filename = file.getOriginalFilename();
////		String path = request.getServletContext().getRealPath("/upload");
////		String fpath = path + "\\" + filename;
////		
////		FileOutputStream fs  = null;
////		
////		try {
////			fs = new FileOutputStream(fpath);
////			fs.write(file.getBytes());
////		} catch (Exception e) {
////			e.printStackTrace();
////		} finally {
////			try {
////				fs.close();
////			} catch (IOException e) {
////				e.printStackTrace();
////			}
////		}
////		
//		
//		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
//		
//		try {
//			
//			joindao.updateImage(member);
//			System.out.println("ddddddddd");
//			
//		} catch (Exception e) {
//			
//			e.printStackTrace();
//		}
//	}
	// 예약 내역 불러오기
	public List<MemberBooking> bookinglist(Integer tagnumber , Integer status) {
		List<MemberBooking> list = null;
		
		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
		
		list = joindao.bookinglist(tagnumber , status);
		System.out.println(list);
		return list;
	}
	
	// 리뷰 인서트
	public void insertReview(CustomerReview customerreview) {
		
		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
		
		joindao.insertReview(customerreview);
	}
	
	// 리뷰 작성시 상태 업데이트 
	public void updateReviewReservation(Integer booking_no) {
		
		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
		
		joindao.updateReviewReservation(booking_no);
	}
	
	// 취소 사유 컬럼 업데이트 
	public int updateReason( String cancelcontent , Integer booking_no) {
		
		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
		
		int result = joindao.updateCancelReason( cancelcontent , booking_no);
		
		return result;
	}
	
	// 취소 하면 STATUS = 4 로 업데이트 
	
	public int updateCancelReservation(Integer booking_no) {
		
		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
		
		int result = joindao.updateCancelStatus(booking_no);
		
		return result;
	}
	
	//결제 하면 payment 결제여부 0에서 1로 업데이트 
	public void updatePayment(Integer booking_no) {
		
		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
		
		 joindao.updatePayment(booking_no);
					
	}
	
	//결제 하면 Status 8로 업데이틑
	public void updateStatus(Integer booking_no) {
		JoinDao joindao = sqlsession.getMapper(JoinDao.class);
		
		 joindao.updateStatusbook(booking_no);
	}

}
