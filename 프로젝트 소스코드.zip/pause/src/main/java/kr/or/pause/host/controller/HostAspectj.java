package kr.or.pause.host.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import kr.or.pause.dto.Host;
import kr.or.pause.dto.HostRoom;
import kr.or.pause.dto.PauseMember;
import kr.or.pause.host.service.HostService;
import kr.or.pause.login.service.JoinService;

@Aspect
@Component
public class HostAspectj {

	@Autowired
	private PauseMember pausemember;
	
	@Autowired
	private JoinService joinservice;
	
	public PauseMember getPauseMember(Principal principal) {
		return joinservice.getPauseMember(principal.getName());
	}
	
	@Bean
	public PauseMember getPauseMember() {
		return new PauseMember();
	}


	@Autowired
	private HostService hostservice;

	/**
	 * 숙소 등록이 진행될 때 마다 호스트정보와 등록되는 숙소의 정보를 세션에 저장한다.
	 * 
	 * @param pjp
	 * @return
	 */
	@Around("!execution (* kr.or.pause.host.controller.HostController.hostGet*(..)) && execution (* kr.or.pause.host.controller.HostController.*(..))")
	public Object postLoadSaveData(ProceedingJoinPoint pjp) {
		
		HttpSession session = ((ServletRequestAttributes) (RequestContextHolder.currentRequestAttributes()))
				.getRequest().getSession();
		
		
		for (Object args : pjp.getArgs()) {
			if (args instanceof Principal) {
				pausemember = getPauseMember((Principal)args);
			}
		}

		int tagnumber = pausemember.getTagnumber();
		
		session.setAttribute("pausemember", pausemember);
		
		Host host = hostservice.selectHost(tagnumber);
		if(host == null) {
			return proceed(pjp);
		}
		
		HostRoom hostRoom = hostservice.selectSavedHostRoom(host);

		session.setAttribute("host", host);
		session.setAttribute("hostRoom", hostRoom);

		System.out.println(pjp.getSignature().getName());

		if (pjp.getSignature().getName().equals("hostlocation")) {
			return proceed(pjp);
		}

		if (host == null || hostRoom == null) {
			return "host/hostregisterbegin";
		}

		for (Object args : pjp.getArgs()) {
			if (args instanceof HostRoom) {
				((HostRoom) args).setNo(hostRoom.getNo());
			}
		}

		return proceed(pjp);
	}

	/**
	 * 저장된 정보를 세션에 저장한다.
	 * 
	 * @param pjp
	 * @return
	 */
	@Around("execution (* kr.or.pause.host.controller.HostController.hostGet*(..))")
	public Object getLoadSaveData(ProceedingJoinPoint pjp) {
		
		for (Object args : pjp.getArgs()) {
			
			if(args instanceof Boolean) {
				if((boolean) args) {
					return proceed(pjp);
				}
			}
			
			if (args instanceof Principal) {
				pausemember = getPauseMember((Principal)args);
			}
		}

		HttpSession session = ((ServletRequestAttributes) (RequestContextHolder.currentRequestAttributes()))
				.getRequest().getSession();

		int tagnumber = pausemember.getTagnumber();

		Host host = hostservice.selectHost(tagnumber);
		session.setAttribute("host", host);
		
		if(host == null) {
			return proceed(pjp);
		}

		HostRoom hostRoom = hostservice.selectSavedHostRoom(host);

		
		session.setAttribute("hostRoom", hostRoom);

		System.out.println(pjp.getSignature().getName());

		Object obj = loadSavdeData(hostRoom);

		return obj;
	}

	/**
	 * host와 숙소의 정보를 찾아서 parameter로 넘겨준다
	 * 
	 * @param pjp
	 * @return
	 */
	@Around("execution (* kr.or.pause.host.controller.HostMainController.*(..)) || execution (* kr.or.pause.booking.controller.BookingController.*(..))")
	public Object getHostInfo(ProceedingJoinPoint pjp) {
		
		for (Object args : pjp.getArgs()) {
			if (args instanceof Principal) {
				pausemember = getPauseMember((Principal)args);
			}
		}

		// TODO 등록된 pausemeber를 어떻게 가져올 것인가
		int tagnumber = pausemember.getTagnumber();

		Host host = hostservice.selectHost(tagnumber);

		if (host == null) {
			return "redirect:failure.do";
		}

//		for (Object args : pjp.getArgs()) {
//			if(args instanceof Host) {
//				((Host) args).setHost_no(host.getHost_no());
//				((Host) args).setIncome(host.getIncome());
//				((Host) args).setTagnumber(host.getTagnumber());
//				((Host) args).setAuth_identification(host.getAuth_identification());
//			}
//		}

		HttpSession session = ((ServletRequestAttributes) (RequestContextHolder.currentRequestAttributes()))
				.getRequest().getSession();

		session.setAttribute("host", host);
		session.setAttribute("pausemember", pausemember);

		return proceed(pjp);
	}

	@Around("execution (* kr.or.pause.host.controller.HostMainController.mainhostpage(..))")
	public Object getHostInfoBooking(ProceedingJoinPoint pjp) {
		
		for (Object args : pjp.getArgs()) {
			if (args instanceof Principal) {
				pausemember = getPauseMember((Principal)args);
			}
		}

		int tagnumber = pausemember.getTagnumber();

		Host host = hostservice.selectHost(tagnumber);

		if (host == null) {
			return "redirect:failure.do";
		}

		HttpSession session = ((ServletRequestAttributes) (RequestContextHolder.currentRequestAttributes()))
				.getRequest().getSession();

		session.setAttribute("host", host);

		return proceed(pjp);
	}

	private Object proceed(ProceedingJoinPoint pjp) {
		Object returnobj = null;

		try {
			returnobj = pjp.proceed();
		} catch (Throwable e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return returnobj;
	}

	private Object loadSavdeData(HostRoom hostRoom) {
		Object obj = null;

		switch (hostRoom == null ? "" : hostRoom.getStatus()) {
		case "1":
			obj = "host/hostlocation";
			break;

		case "2":
			obj = "host/hostcapacity";
			break;

		case "3":
			obj = "host/hostamenity";
			break;

		case "4":
			obj = "host/beforeroompicture";
			break;

		case "5":
			obj = "host/hostroomname";
			break;

		case "6":
			obj = "host/hostroomintroduce";
			break;

		case "7":
			obj = "host/hostroomcost";
			break;

		case "8":
			obj = "host/hostrule";
			break;

		default:
			obj = "host/hostregisterbegin";
			break;
		}

		return obj;
	}

}
