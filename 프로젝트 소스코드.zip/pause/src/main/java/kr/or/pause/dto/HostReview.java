package kr.or.pause.dto;

public class HostReview {
	private int host_review_no;
	private String write_date;
	private int avg;
	private String content;
	private int tagnumber;
	private int booking_no;
	public int getHost_review_no() {
		return host_review_no;
	}
	public void setHost_review_no(int host_review_no) {
		this.host_review_no = host_review_no;
	}
	public String getWrite_date() {
		return write_date;
	}
	public void setWrite_date(String write_date) {
		this.write_date = write_date;
	}
	public int getAvg() {
		return avg;
	}
	public void setAvg(int avg) {
		this.avg = avg;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public int getTagnumber() {
		return tagnumber;
	}
	public void setTagnumber(int tagnumber) {
		this.tagnumber = tagnumber;
	}
	public int getBooking_no() {
		return booking_no;
	}
	public void setBooking_no(int booking_no) {
		this.booking_no = booking_no;
	}
	
	@Override
	public String toString() {
		return "HostReview [host_review_no=" + host_review_no + ", write_date=" + write_date + ", avg=" + avg
				+ ", content=" + content + ", tagnumber=" + tagnumber + ", booking_no=" + booking_no + "]";
	}
	
	
}
