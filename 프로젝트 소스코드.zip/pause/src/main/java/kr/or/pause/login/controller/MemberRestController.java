package kr.or.pause.login.controller;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kr.or.pause.login.service.JoinService;
import kr.or.pause.dto.CustomerReview;
import kr.or.pause.dto.MemberBooking;
import kr.or.pause.dto.PauseMember;
import java.util.List;
import java.security.Principal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
public class MemberRestController {
	
	@Autowired
	private JoinService joinservice;
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
	
	@RequestMapping(value = "/list.do" , method=RequestMethod.GET)
	public List<MemberBooking> bookinglist(@RequestParam (value= "tagnumber" , required = true) Integer tagnumber ,
										   @RequestParam(value ="status", required = true) Integer status) {
		System.out.println(tagnumber);
		List<MemberBooking> list = null;
		
		try {
			list = joinservice.bookinglist(tagnumber, status);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return list;
	}
	
	@RequestMapping(value = "/cancelReservation.do" , method = {RequestMethod.PUT , RequestMethod.GET})
	public boolean updateCancelReservation( 
														    @RequestParam("cancelcontent") String cancelcontent,
														    @RequestParam("booking_no") Integer booking_no ) {
												         
		boolean result = true;
		
		System.out.println(cancelcontent);
		System.out.println(booking_no);
		
		try {			
			int result1 = joinservice.updateReason(cancelcontent , booking_no);
			int result2 = joinservice.updateCancelReservation(booking_no);
			if(result1 > 0 && result2 > 0) {
				result = true;
			} else {
				result = false;
			}

			System.out.println(cancelcontent);
		} catch (Exception e) {
			
			e.printStackTrace();						
		}		
		return result;
	}
	
	//payment가 0에서 1로 바뀌는 
	@RequestMapping(value ="/updatePayment.do" , method = {RequestMethod.PUT , RequestMethod.GET})
	
	public void updatePayment(Integer booking_no) {
		try {
			joinservice.updatePayment(booking_no);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//status가 8로 바뀌는 
	@RequestMapping(value = "/updateStatuss.do" , method = {RequestMethod.PUT , RequestMethod.GET})
	public void updateStatusbook(Integer booking_no) {
		try {
			joinservice.updateStatus(booking_no);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
