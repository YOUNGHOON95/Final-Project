package kr.or.pause.booking.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import kr.or.pause.booking.service.BookingService;
import kr.or.pause.dto.Booking;
import kr.or.pause.dto.ChartData;

@RestController
public class BookingRestController {
	
	@Autowired
	private BookingService bookingService;
	
	
	@RequestMapping(value="/giveme.do", method=RequestMethod.GET)
	public List<Booking> hostBooking(String host_no) {
		System.out.println("giveme.do");
		List<Booking> list = new ArrayList<Booking>();
		try {
			list = bookingService.getBooking(Integer.parseInt(host_no));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	@RequestMapping(value="/submitHostReivew.do", method=RequestMethod.POST)
	public void submitHostReivew(int booking_no, int tagnumber, int avg, String content) {
		System.out.println("submitHostReivew.do");
		int result;
		System.out.println(booking_no);
		System.out.println(tagnumber);
		System.out.println(avg);
		System.out.println(content);
		try {
			result = bookingService.insertHostReview(booking_no, avg, tagnumber, content);
			System.out.println(result);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	@RequestMapping(value="/chartInfo.do", method=RequestMethod.GET)
	public List<ChartData> getChartData(String host_no) {
		System.out.println("chartInfo.do");
		List<ChartData> list = new ArrayList<ChartData>();
		try {
			list = bookingService.getChart(Integer.parseInt(host_no));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
}
