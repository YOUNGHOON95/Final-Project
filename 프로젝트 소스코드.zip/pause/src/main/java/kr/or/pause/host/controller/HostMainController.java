package kr.or.pause.host.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import kr.or.pause.dto.Chat;
import kr.or.pause.dto.Host;
import kr.or.pause.dto.HostBookingPage;
import kr.or.pause.dto.HostReview;
import kr.or.pause.dto.HostRoom;
import kr.or.pause.dto.PauseHost;
import kr.or.pause.dto.PauseMember;
import kr.or.pause.host.service.HostService;
import kr.or.pause.login.service.JoinService;

@Controller
public class HostMainController {

	@Autowired
	private HostService hostservice;
	
	@Autowired
	private JoinService joinservice;
	
	// 호스트 메세지
	@RequestMapping("mainhostmassage.do")
	public String mainhostmassage(Principal principal, HttpServletRequest request, Model model) {
		
		Host host = (Host) request.getSession().getAttribute("host");
		
		PauseMember pausemember = (PauseMember) request.getSession().getAttribute("pausemember");

		List<Map<String, String>> chatList = hostservice.getMessageNav(Integer.toString(host.getTagnumber()));
		
		System.out.println(chatList);
		model.addAttribute("chatList", chatList);
		model.addAttribute("host", host);
		
		return "host/mainhostmassage";
	}
	
	// 호스트 예약 페이지
	@RequestMapping("mainreservationpage.do")
	public String mainreservationpage(Principal principal) {
		return "host/mainreservationpage";
	}
	// 호스트 달력 페이지

	// 호스트 숙소관리 페이지
	@RequestMapping("mainroompage.do")
	public String mainroompage(Principal principal) {
		return "host/mainroompage";
	}

	// 호스트 후기 페이지
	@RequestMapping("main_host_review.do")
	public String main_host_review(Principal principal) {
		return "host/main_host_review";
	}
	
	// 호스트 실적 페이지
	@RequestMapping("mainsalespage.do")
	public String mainsalespage(Principal principal) {
		return "host/mainsalespage";
	}

	// 숙소 추가
	@RequestMapping("mainaddroom.do")
	public String mainaddroom(Principal principal) {
		return "host/mainaddroom";
	}

	// 호스트 도움말 페이지
	@RequestMapping("mainhelppage.do")
	public String mainhelppage(Principal principal) {
		return "host/mainhelppage";
	}

	// 호스트 숙소 사진
	@RequestMapping("mainhostroompicture.do")
	public String mainhostroompicture(HostRoom hostRoom, Model model, Principal principal) {
		
		HostRoom sendHostRoom = hostservice.selectroomname(hostRoom.getNo());
		
		ObjectMapper om = new ObjectMapper();
		
		String jsonHostRoom = "";
		try {
			jsonHostRoom = om.writeValueAsString(sendHostRoom);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		model.addAttribute("jsonHostRoom", jsonHostRoom);
		
		model.addAttribute("hostRoom", sendHostRoom);
		
		return "host/mainhostroompicture";
	}

	// 숙소 정보 가져오기
	@RequestMapping(value = "mainhostroominformation.do", method = RequestMethod.GET)
	public String mainhostroominformation(HostRoom hostRoom, Model model, Principal principal) {

		HostRoom sendHostRoom = hostservice.selectroomname(hostRoom.getNo());
		
		ObjectMapper om = new ObjectMapper();
		
		String jsonHostRoom = "";
		try {
			jsonHostRoom = om.writeValueAsString(sendHostRoom);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		model.addAttribute("jsonHostRoom", jsonHostRoom);
		
		model.addAttribute("hostRoom", sendHostRoom);

		return "host/mainhostroominformation";
	}

	// 숙소 정보 가져오기
	@RequestMapping(value = "mainhostroomlist.do", method = RequestMethod.GET)
	public String mainhostroomlist( HttpServletRequest request,
			@RequestParam(value="start", defaultValue="1") int start, 
			@RequestParam(value="end", defaultValue="6") int end, Model model, Principal principal) {
		
		Host host = (Host) request.getSession().getAttribute("host");
		
		List<HostRoom> hostRoomList = hostservice.selectListHostRoom(host, start, end);
		
		model.addAttribute("hostRoom", hostRoomList);

		return "host/mainhostroomlist";
	}

	// 호스트 숙소 편의시설
	@RequestMapping("mainhostroomamenity.do")
	public String mainhostroomamenity(HostRoom hostRoom, Model model, Principal principal) {
		
		HostRoom sendHostRoom = hostservice.selectroomname(hostRoom.getNo());
		
		ObjectMapper om = new ObjectMapper();
		
		String jsonHostRoom = "";
		try {
			jsonHostRoom = om.writeValueAsString(sendHostRoom);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		}
		
		model.addAttribute("jsonHostRoom", jsonHostRoom);
		model.addAttribute("hostRoom", sendHostRoom);
		
		
		return "host/mainhostroomamenity";
	}

}
