package kr.or.pause.host.controller;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import kr.or.pause.dto.Chat;
import kr.or.pause.dto.HostBookingPage;
import kr.or.pause.dto.HostReview;
import kr.or.pause.host.service.HostService;

@RestController
public class HostRestController {
	
	@Autowired
	private HostService hostservice;
	
	@InitBinder
	protected void initBinder(WebDataBinder binder) {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}
	
	@RequestMapping(value = "/bookinglist.do" , method = RequestMethod.GET)
	public List<HostBookingPage> hostBookingList(@RequestParam(value = "host_no" ,required = true) int host_no ,
												 @RequestParam(value = "status" , required = true) int status) {
		
		System.out.println(host_no);
		
		List<HostBookingPage> list = null;
		try {
			list = hostservice.hostBookingList(host_no, status);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return list;
	}
	
	// 호스트가 승인 했을때 status 컬럼 변경
		@RequestMapping(value = "/updateStatus.do" , method = RequestMethod.GET)
		public boolean updateStatus(Integer booking_no) {
			
			boolean result = hostservice.updateStatus(booking_no);
			return result;
		}

	// 호스트가 거절 했을때 
		@RequestMapping(value = "/rejectStatus.do" , method = RequestMethod.GET)
		public boolean rejectBooking(Integer booking_no) {
			
			boolean result = hostservice.rejectStatus(booking_no);
			
			return result;
		}
		
	// 호스트 후기 
		
		// 다른 호스트들이 작성한 고객 리뷰 보기
		@RequestMapping(value = "/confirmreview.do" , method = RequestMethod.GET)
		public List<HostReview>hostReviewlist(Integer tagnumber) {
			List<HostReview> list = hostservice.hostReviewlist(tagnumber);
			
			return list;
			
		}
		
		@RequestMapping(value = "/insertchat.do" , method = RequestMethod.POST)
		public void insertChatInfo(Chat chat) {
			try {
				hostservice.insertChat(chat);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
}
