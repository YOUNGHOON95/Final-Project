package kr.or.pause.dto;

import lombok.Data;

@Data
public class HostGuestBooking {
	private int host_tagnumber;
	private String host_phone_number;
    private String host_email;
    private String host_name;
    private String host_profile_img;
    private int guest_tagnumber;
    private String guest_phone_number;
    private String guest_email;
    private String guest_name;
    private String guest_profile_img;
    private String guest_coupon;
    
    // booking info
    private int booking_no;
    private int host_no; // room_no
    private String room_name;
    private String check_in;
    private String check_out;
    private String status;
    private String file1; 
    private int reservation_capacity; 
    private String rule;
}
