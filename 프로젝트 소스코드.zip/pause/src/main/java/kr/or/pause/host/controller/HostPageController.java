package kr.or.pause.host.controller;

import java.security.Principal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import kr.or.pause.dto.EmailDTO;
import kr.or.pause.dto.HostBookingPage;
import kr.or.pause.dto.HostReview;
import kr.or.pause.dto.PauseHost;
import kr.or.pause.dto.PauseMember;
import kr.or.pause.dto.ReservationEmail;
import kr.or.pause.host.service.HostService;
import kr.or.pause.login.service.EmailService;
import kr.or.pause.login.service.JoinService;

@Controller
public class HostPageController {
	@Autowired
	private JoinService joinservice;
	
	@Autowired
	private HostService hostservice;
	
	@Autowired
	private EmailService emailservice;
	
	@RequestMapping(value = "goHost.do" , method = RequestMethod.GET)
	public String goHostPage(Model model, Principal principal) {
		PauseMember pausemember = joinservice.getPauseMember(principal.getName());
		PauseHost pausehost = hostservice.getHostMember(pausemember.getTagnumber());
		 List<HostBookingPage> list = hostservice.hostBookingList(pausehost.getHost_no(), 1);
		 List<HostReview> reviewlist = hostservice.hostReviewlist(pausemember.getTagnumber());
		model.addAttribute("bookinglist", list);
		
		model.addAttribute("pausehost", pausehost);
	
		
		return "host/mainhostpage";
	}
	
	@ResponseBody
	@RequestMapping("sendreservation.do") // 확인 (메일발송) 버튼을 누르면 맵핑되는 메소드
	//public String send(kr.or.pause.dto.EmailDTO dto, Model model) {
	public Model send(HttpServletRequest request, Model model) {
		
		try {
			
			ReservationEmail  dto = null;
			dto = new ReservationEmail((String)request.getParameter("receiveMail"),(String)request.getParameter("message"));
			 emailservice.sendReservationMail(dto); // dto (메일관련 정보)를 sendMail에 저장함
			model.addAttribute("message", "이메일이 발송되었습니다."); // 이메일이 발송되었다는 메시지를 출력시킨다.
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			model.addAttribute("message", "이메일 발송 실패..."); // 이메일 발송이 실패되었다는 메시지를 출력
		}
		return null; // 실패했으므로 다시 write jsp 페이지로 이동함
	}
	
	
	
}
