package kr.or.pause.dto;

import java.sql.Date;

// 부킹 테이블
public class MemberBooking {
	
	private int booking_no;
	private Date check_in;
	private Date check_out;
	private int reservation_capacity;
	private String admission;
	private String payment;
	private long tagnumber;
	private int no; // 방번호
	private int pay; // 결제 금액
	private Date pay_date; 
	private String status; // 예약 상태
	private Date reservation_date; // 예약 승인 날짜
	private Date reservation_req_date; // 예약 요청 날짜
	private HostRoom hostroom; // 조인 해야하는 dto
	private String cancelcontent; // 취소 사유 
	
	
	public String getCancelcontent() {
		return cancelcontent;
	}
	public void setCancelcontent(String cancelcontent) {
		this.cancelcontent = cancelcontent;
	}
	public HostRoom getHostroom() {
		return hostroom;
	}
	public void setHostroom(HostRoom hostroom) {
		this.hostroom = hostroom;
	}
	public int getBooking_no() {
		return booking_no;
	}
	public void setBooking_no(int booking_no) {
		this.booking_no = booking_no;
	}
	public Date getCheck_in() {
		return check_in;
	}
	public void setCheck_in(Date check_in) {
		this.check_in = check_in;
	}
	public Date getCheck_out() {
		return check_out;
	}
	public void setCheck_out(Date check_out) {
		this.check_out = check_out;
	}
	public int getReservation_capacity() {
		return reservation_capacity;
	}
	public void setReservation_capacity(int reservation_capacity) {
		this.reservation_capacity = reservation_capacity;
	}
	public String getAdmission() {
		return admission;
	}
	public void setAdmission(String admission) {
		this.admission = admission;
	}
	public String getPayment() {
		return payment;
	}
	public void setPayment(String payment) {
		this.payment = payment;
	}
	public long getTagnumber() {
		return tagnumber;
	}
	public void setTagnumber(long tagnumber) {
		this.tagnumber = tagnumber;
	}
	public int getNo() {
		return no;
	}
	public void setNo(int no) {
		this.no = no;
	}
	public int getPay() {
		return pay;
	}
	public void setPay(int pay) {
		this.pay = pay;
	}
	public Date getPay_date() {
		return pay_date;
	}
	public void setPay_date(Date pay_date) {
		this.pay_date = pay_date;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getReservation_date() {
		return reservation_date;
	}
	public void setReservation_date(Date reservation_date) {
		this.reservation_date = reservation_date;
	}
	public Date getReservation_req_date() {
		return reservation_req_date;
	}
	public void setReservation_req_date(Date reservation_req_date) {
		this.reservation_req_date = reservation_req_date;
	}
	@Override
	public String toString() {
		return "MemberBooking [booking_no=" + booking_no + ", check_in=" + check_in + ", check_out=" + check_out
				+ ", reservation_capacity=" + reservation_capacity + ", admission=" + admission + ", payment=" + payment
				+ ", tagnumber=" + tagnumber + ", no=" + no + ", pay=" + pay + ", pay_date=" + pay_date + ", status="
				+ status + ", reservation_date=" + reservation_date + ", reservation_req_date=" + reservation_req_date
				+ ", hostroom=" + hostroom + ", cancelcontent=" + cancelcontent + "]";
	}
	
	
	
	
	
	
	
}



