package kr.or.pause.guest.controller;

import java.security.Principal;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import kr.or.pause.commons.FileUtils;
import kr.or.pause.dto.ReservationCard;
import kr.or.pause.dto.SearchCard;
import kr.or.pause.dto.SearchCardAjax;
import kr.or.pause.dto.SearchFilter;
import kr.or.pause.guest.service.GuestService;
import kr.or.pause.login.service.JoinService;

@RestController
public class GuestRestConroller {
	
	@Autowired
	private GuestService guestService;
	
	@Autowired
	private BCryptPasswordEncoder bCryptPasswordEncoder;
	
	////////////////////검색창//////////////////////////////////////////
	
	@RequestMapping(value = "/filter.do", method = RequestMethod.GET)
	public List<SearchCard> getSearchCardByFilter(SearchFilter searchFilter) {
		System.out.println("filter.do");
		System.out.println(searchFilter);
		List<SearchCard> list = new ArrayList<SearchCard>();
		try {
			list = guestService.getSeachCardByFilter(searchFilter);
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	@RequestMapping(value = "/searchCard.do", method = RequestMethod.GET)
	public List<SearchCard> getSearchCardByAjax(SearchCardAjax searchcard) throws ClassNotFoundException, SQLException{
		
		System.out.println(searchcard);
		List<SearchCard> list = new ArrayList<SearchCard>();
		list = guestService.getSerachCardAjax(searchcard);
		
		return list;
	}
	
	@RequestMapping(value = "/getWating.do", method = RequestMethod.POST)
	public List<ReservationCard> getWatingReservationCard(int tagnumber) throws ClassNotFoundException, SQLException{
		
		List<ReservationCard> list = new ArrayList<ReservationCard>();
		list = guestService.getWatingReservationCard(tagnumber);
		
		return list;
	}
	
	@RequestMapping(value = "/getConfirm.do", method = RequestMethod.POST)
	public List<ReservationCard> getConfirmReservationCard(int tagnumber) throws ClassNotFoundException, SQLException{
		
		List<ReservationCard> list = new ArrayList<ReservationCard>();
		list = guestService.getConfirmReservationCard(tagnumber);
		
		return list;
	}
	
	@RequestMapping(value = "/getComplete.do", method = RequestMethod.POST)
	public List<ReservationCard> getCompleteReservationCard(int tagnumber) throws ClassNotFoundException, SQLException{
		
		List<ReservationCard> list = new ArrayList<ReservationCard>();
		list = guestService.getCompleteReservationCard(tagnumber);
		
		return list;
	}
	//////////////////////////////////회원정보 수정//////////////////////
	@RequestMapping(value = "/getmemberinfo.do", method = RequestMethod.POST)
	public Map<String,Object> getMemberInfo(int tagnumber) throws ClassNotFoundException, SQLException{
		
		Map<String, Object> map = new HashMap<String, Object>();
		map = guestService.getMemberInfo(tagnumber);
		
		return map;
	}
	@RequestMapping(value = "/editmemberimg.do", method = RequestMethod.POST)
	public int editMemberProfile_img(@RequestParam(value = "profile_img" ,required = false) MultipartFile file, Principal principal, HttpServletRequest request) throws ClassNotFoundException, SQLException {
		
		int tagnumber = guestService.getTagnumByPhonenum(principal.getName());
		String profile_img = FileUtils.saveFiles(file, request);
		int result = guestService.editMemberProfile_img(tagnumber, profile_img);
		
		return result;
	}
	@RequestMapping(value = "/editmembername.do", method = RequestMethod.POST)
	public int editMemberName(int tagnumber,String name) throws ClassNotFoundException, SQLException {
		
		int result = guestService.editMemberName(tagnumber, name);
		
		return result;
	}
	@RequestMapping(value = "/editmemberpwd.do", method = RequestMethod.POST)
	public int editMemberPassword(@Param("tagnumber") int tagnumber,@Param("password")String password) throws ClassNotFoundException, SQLException {
		
		String encodingpassword = this.bCryptPasswordEncoder.encode(password);
		
		int result = guestService.editMemberPassword(tagnumber, encodingpassword);
		
		return result;
	}
	@RequestMapping(value = "/editmembereamil.do", method = RequestMethod.POST)
	public int editMemberEmail(int tagnumber,String email) throws ClassNotFoundException, SQLException {
		
		
		int result = guestService.editMemberEmail(tagnumber, email);
		
		return result;
	}
	
	@RequestMapping(value = "/editmemberphone.do", method = RequestMethod.POST)
	public int editMemberPhone(int tagnumber, String phone_number) throws ClassNotFoundException, SQLException {
		
		int result = guestService.editMemberPhone_number(tagnumber, phone_number);
		
		return result;
	}
}


























