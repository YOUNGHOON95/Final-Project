package kr.or.pause.dto;

import java.sql.Date;

import lombok.Data;

@Data
public class HostReviewForHost {
	private int host_review_no;
	private int host_no;
	private String name;
	private String room_name;
	private Date write_date;
	private int booking_no;
	private String tagnumber;
	private String content;
	private int avg;
	private String profile_img;
}
