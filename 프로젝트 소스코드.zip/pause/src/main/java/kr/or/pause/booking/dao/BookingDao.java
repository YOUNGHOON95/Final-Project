package kr.or.pause.booking.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import kr.or.pause.dto.Booking;
import kr.or.pause.dto.ChartData;
import kr.or.pause.dto.Host_review;

public interface BookingDao {
	public ArrayList<Booking> getBooking(int host_no) throws ClassNotFoundException, SQLException;
	public ArrayList<ChartData> getChart(int host_no) throws ClassNotFoundException, SQLException;
	public int insertHost_review(Host_review hr) throws ClassNotFoundException, SQLException;
	public int updateHost_review(Host_review hr) throws ClassNotFoundException, SQLException;
}
