package kr.or.pause.booking.controller;

import java.security.Principal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import kr.or.pause.dto.PauseMember;
import kr.or.pause.login.service.JoinService;


@Controller
public class BookingController {
	
	private JoinService joinservice;
	
	@Autowired
	private PauseMember pausemember;
	
	public PauseMember getPauseMember(Principal principal) {
		return joinservice.getPauseMember(principal.getName());
	}
	
	
	@RequestMapping("host_booking.do")
	public String hostBooking(Principal principal, Model model) {
		return "host/booking/host_booking";
	}
	
	@RequestMapping("hostcalendar.do")
	public String hostcalendar(Principal principal, Model model) {
		return "host/booking/hostcalendar";
	}
	
	@RequestMapping("host_chart.do")
	public String hostChart(Principal principal, Model model) {
		return "host/booking/host_chart";
	}
}
