package kr.or.pause.guest.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import kr.or.pause.dto.BookingInsert;
import kr.or.pause.dto.DetailCusReview;
import kr.or.pause.dto.DetailPage;
import kr.or.pause.dto.ReservationCard;
import kr.or.pause.dto.SearchCard;
import kr.or.pause.dto.SearchCardAjax;
import kr.or.pause.dto.SearchFilter;

public interface GuestDao {
	
	//메인 화면에서 검색한 결과
	public List<SearchCard> getSearchCard(int capacity, String addr, String check_in, String check_out) throws ClassNotFoundException, SQLException;
	
	//필터를 적용하여 검색한 결과
	public List<SearchCard> getSearchCardByFilter(SearchFilter searchFilter) throws ClassNotFoundException, SQLException;
	
	//상세 페이지 보기
	public DetailPage getDetailPage(int no) throws ClassNotFoundException , SQLException;
	
	//상세 페이지 리뷰 가져오기
	public List<DetailCusReview> getCusReview (int no) throws ClassNotFoundException , SQLException;
	
	//phone_number로 tagnumber 가져오기
	public int getTagnumber(String phone_number) throws ClassNotFoundException , SQLException;
	
	//메인화면에서 검색한 결과 local storage 로 찾기
	public List<SearchCard> getSearchCardAjax(SearchCardAjax searchcard) throws ClassNotFoundException, SQLException;
	
	//예약상태(대기) 따른 예약 가져오기
	public List<ReservationCard> getWatingReservationCard(int tagnumber) throws ClassNotFoundException, SQLException;
	
	//예약상태(승인) 따른 예약 가져오기
	public List<ReservationCard> getConfirmReservationCard(int tagnumber) throws ClassNotFoundException, SQLException;
	
	//예약상태(완료) 따른 예약 가져오기
	public List<ReservationCard> getCompleteReservationCard(int tagnumbe) throws ClassNotFoundException, SQLException;
	
	//예약 취소하기
	public int cancelReservation(int booking_no) throws ClassNotFoundException, SQLException;
	
	//예약하기
	public int insertBooking(BookingInsert book) throws ClassNotFoundException, SQLException;
	
	//////////////////////////////////개인정보 수정/////////////////////////////////////////////
	
	//수정할 회원 정보 가져오기
	public Map<String, Object> getMemberInfo(int tagnumber) throws ClassNotFoundException, SQLException;
	
	//게스트 이름 수정
	public int editMemberName(int tagnumber, String name) throws ClassNotFoundException, SQLException;
	
	//게스트 프로필 사진 수정
	public int editMemberProfile_img(int tagnumber,String profile_img) throws ClassNotFoundException, SQLException;
	
	//게스트 비밀번호 수정
	public int editMemberPassword(int tagnumber, String password) throws ClassNotFoundException, SQLException;
	
	//게스트 전화번호 수정
	public int editMemberPhone(int tagnumber, String phone_number) throws ClassNotFoundException, SQLException;
	
	//게스트 이메일 수정
	public int editMemberEmail(int tagnumber, String email) throws ClassNotFoundException, SQLException;
	
	/////////////////////////////예약 요청페이지
	
	//예약페이지 필요 데이터 가져오기
	public Map<String, Object> getReservationData(int no) throws ClassNotFoundException, SQLException;
	
	
}
