package kr.or.pause.dto;

import lombok.Data;

@Data
public class ReservationCard {
	private int booking_no;
	private int status;
	private int reservation_capacity;
	private String check_in;
	private String check_out;
	private String reservation_req_date;
	private String file1;
}
