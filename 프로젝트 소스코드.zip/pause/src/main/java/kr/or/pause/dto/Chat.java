package kr.or.pause.dto;

import lombok.Data;

@Data
public class Chat {
	private String msg;
	private String write_date;
	private String from_user;
	private String to_user;
	private int m_check;
	private int count;
	private int booking_no;
}
