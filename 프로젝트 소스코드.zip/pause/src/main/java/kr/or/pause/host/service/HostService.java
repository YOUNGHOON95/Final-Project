package kr.or.pause.host.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import kr.or.pause.dto.Chat;
import kr.or.pause.dto.Host;
import kr.or.pause.dto.HostBookingPage;
import kr.or.pause.dto.HostReview;
import kr.or.pause.dto.HostRoom;
import kr.or.pause.dto.PauseHost;
import kr.or.pause.host.dao.HostDao;

@Service
@Transactional
public class HostService {
	
	@Autowired
	SqlSession sqlsession;
	
	public Host selectHost(int tagnumber ) {
		return sqlsession.getMapper(HostDao.class).selectHost(tagnumber);
	}
	
	public HostRoom selectHostRoom(Host host) {
		return sqlsession.getMapper(HostDao.class).selectHostRoom(host);
	}
	
	public HostRoom selectSavedHostRoom(Host host) {
		return sqlsession.getMapper(HostDao.class).selectSavedHostRoom(host);
	}
	
	public HostRoom selectroomname(int no) {
		HostRoom hostRoom = sqlsession.getMapper(HostDao.class).selectroomname(no); 
		return hostRoom;
	}
	
	/**
	 * host번호를 저장한다.
	 * 
	 * @param tagnumber
	 * @return 등록된 경우 1 그렇지 않으면 0
	 */
	@Transactional
	public int insertHostRegister(int tagnumber) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.insertHostRegister(tagnumber);
		return result;
	}
	
	@Transactional
	public int insertHostRoomRegister(int host_no) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.insertHostRoomRegister(host_no);
		return result;
	}
	
	
	/**
	 * host 등록 시 위치정보를 저장한다.
	 * 
	 * @param hostRoom
	 * @return 등록된 경우 1 그렇지 않으면 0
	 */
	public int updateHostLocation(HostRoom hostRoom) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.updateHostLocation(hostRoom);
		return result;
	}
	
	/**
	 * 호스트 정보 가져온다.
	 * @param tagnumber
	 * @return 회원 tagnumber을 통해서 호스트 테이블 정보 받아온다.
	 */
	public PauseHost getHostMember(int tagnumber) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		PauseHost pausehost = hostdao.getPauseHost(tagnumber);
		return pausehost;
	}
	
	public List<HostBookingPage> hostBookingList(int host_no , int status) {
		List<HostBookingPage> list = null;
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		list = hostdao.hostbookinglist(host_no, status);
		return list;
	}
	
	/**
	 * 호스트가 승인 누르면 예약상태 컬럼 2번으로 변경
	 * @param booking_no
	 * @return 
	 */
	public boolean updateStatus(Integer booking_no) {
		
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		
		boolean result = hostdao.updateStatus(booking_no);
		
		return result;
		
	}
	
	/**
	 * 호스트가 거절 누르면 예약상태 컬럼 3번으로 변경
	 * @param booking_no
	 * @return
	 */
	public boolean rejectStatus(Integer booking_no) {
		
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		
		boolean result = hostdao.rejectBooking(booking_no);
		
		return result;
	}
	
	public List<HostReview> hostReviewlist(Integer tagnumber) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		
		List<HostReview> list = null;
		
		list = hostdao.hostReviewlist(tagnumber);
		
		return list;
	}
	@Transactional
	public int updateHostCapacityAndCountBed(HostRoom hostRoom) {
		int result = updateHostCapacity(hostRoom);
		int result2 = updateHostCountBed(hostRoom);
		return (result > 0 && result2 > 0) ? 1 : 0;
	}
	
	public int updateHostCapacity(HostRoom hostRoom) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.updateHostCapacity(hostRoom);
		return result;
	}
	
	public int updateHostCountBed(HostRoom hostRoom) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = 0;
		if(hostdao.selectOptionAmenity(hostRoom) > 0) {
			result = hostdao.updateHostCountBed(hostRoom);
		} else {
			result = hostdao.insertOptionAmenity(hostRoom);
		}
		return result;
	}
	
	public int updateOptionAmenity(HostRoom hostRoom) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.updateOptionAmenity(hostRoom);
		return result;
	}
	
	public int updateFile(Map<String, String> map, HostRoom hostRoom) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.updateFile(map, hostRoom);
		return result;
	}
	
	public int updateFile2(Map<String, String> map, HostRoom hostRoom) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.updateFile2(map, hostRoom);
		return result;
	}
	
	public int updateHostRoomName(HostRoom hostRoom) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.updateHostRoomName(hostRoom);
		return result;
	}
	
	public int updateHostRoomInfo(HostRoom hostRoom) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.updateHostRoomInfo(hostRoom);
		return result;
	}
	
	public int updateHostCost(HostRoom hostRoom) {
		HostDao	hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.updateHostCost(hostRoom);
		return result;
	}
	
	public int updateHostComplete(HostRoom hostRoom) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.updateHostComplete(hostRoom);
		return result;
	}
	
	public List<HostRoom> selectListHostRoom(Host host, int start, int end) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		List<HostRoom> result = hostdao.selectListHostRoom(host, start, end);
		return result;
	}
	
	public int updateHostRoomDynamic(HostRoom hostRoom) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.updateHostRoomDynamic(hostRoom);
		return result;
	}
	
	public List<Map<String, String>> getMessageNav(String host_tagnumber) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		List<Map<String, String>> chatList = hostdao.getMessageNav(host_tagnumber);
		return chatList;
	}
	
	public Map<String, String> getDetail(Chat chat) {
		return sqlsession.getMapper(HostDao.class).getDetail(chat);
	}
	
	
	public int getCount(Chat chat) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		int result = hostdao.getCount(chat);
		return result;
	}
	
	public List<Chat> getMessageInteract(Chat chat) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		return hostdao.getMessageInteract(chat);
		
	}
	
	public int insertChat(Chat chat) {
		HostDao hostdao = sqlsession.getMapper(HostDao.class);
		return hostdao.insertChat(chat);
	}
	
	public String getTagNumber(String phone_number) {
		return sqlsession.getMapper(HostDao.class).getTagNumber(phone_number);
	}
	
	public int insertHostRole(String role_name, int tagnumber, String phone_number) {
		return sqlsession.getMapper(HostDao.class).insertHostRole(role_name, tagnumber, phone_number);
	}
	
	public int updatemessageconfirm(Chat chat) {
		return sqlsession.getMapper(HostDao.class).updatemessageconfirm(chat);
	}
	
}
