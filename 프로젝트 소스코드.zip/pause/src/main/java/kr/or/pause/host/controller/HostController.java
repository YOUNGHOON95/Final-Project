package kr.or.pause.host.controller;

import java.security.Principal;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import kr.or.pause.commons.FileUtils;
import kr.or.pause.dto.Host;
import kr.or.pause.dto.HostRoom;
import kr.or.pause.dto.PauseMember;
import kr.or.pause.host.service.HostService;
import kr.or.pause.login.service.JoinService;

@Controller
@Transactional
public class HostController {
	
	@Autowired
	private HostService hostservice;
	
	//TODO 메인화면 완료 시 TEST CODE 수정
	/*********** TEST CODE ************/
	
	@Autowired
	private PauseMember pausemember;
	
	
	@RequestMapping("home.do")
	public String hostGetregister(Principal principal, boolean back) {
		return "host/hostregisterbegin";
	}
	/*********** TEST CODE ************/
	
	/**
	 * 호스팅 시작하기 페이지에서 시작하기 버튼 클릭 시
	 * 호스트 번호를 저장한다. 
	 * 
	 * @param host_no
	 * @return 호스트 번호 등록 성공 시 다음 단계로 이동
	 * @since 2021/06/11
	 */
	@Transactional
	@RequestMapping(value = "hostlocation.do", method = RequestMethod.POST)
	public String hostlocation(HttpServletRequest request, Principal principal) {
		pausemember = joinservice.getPauseMember(principal.getName());
		
		Object host = null;
		
		if(request.getSession().getAttribute("host") != null) {
			host = request.getSession().getAttribute("host");
		}
		
		// 만약 같은 태그번호로 host등록이 되어있다면 등록 x
		int result = 0;
		if(host == null) {
			result = hostservice.insertHostRegister(pausemember.getTagnumber());
		} else {
			result = 1;
		}
		
		host = hostservice.selectHost(pausemember.getTagnumber());
		
		int result2 = hostservice.insertHostRoomRegister(((Host) host).getHost_no());
		String view = "";
		// host 등록 성공시
		if(result > 0 && result2 > 0) {
			// 주소 정보 입력으로 이동
			view = "host/hostlocation";
		}
		// host 등록 실패시
		else {
			view = "";
		}
		
		return view;
	}
	
	@RequestMapping(value = "hostlocation.do", method = RequestMethod.GET)
	public String hostGetLocation(Principal principal, boolean back) {
		return "host/hostlocation";
	}
	
	/**
	 * 호스트 위치정보입력 페이지에서  
	 * 위치정보 입력 성공 시 다음단계로 이동한다.
	 * 
	 * @param hostRoom
	 * @return 다음 단계(예약인원)로 이동한다.
	 */
	@RequestMapping(value = "hostcapacity.do", method = RequestMethod.POST)
	public String insertLocation(HostRoom hostRoom, Principal principal) {
		
		int result = hostservice.updateHostLocation(hostRoom);
		
		String view = "";
		
		// 주소등록 성공시
		if(result > 0) {
			// 수용인원 입력 페이지로 이동한다.
			view = "host/hostcapacity";
		}
		// 주소등록 실패시
		else {
			view = "";
		}
		
		return view;
	}
	
	@RequestMapping(value = "hostcapacity.do", method = RequestMethod.GET)
	public String hostGetCapacity(Principal principal, boolean back) {
		return "host/hostcapacity";
	}

	@RequestMapping("main1.do")
	public String hostexit(Principal principal) {
		return "host/pause_main";
	}
	
	
	
	
	
	/**
	 * 수용인원, 침대 수를 입력 받은 뒤
	 * 편의시설 입력 페이지로 이동한다.
	 * 
	 * @param hostRoom
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "hostamenity.do", method = RequestMethod.POST)
	public String hostamenity(HostRoom hostRoom, Principal principal) {
		
		int result = hostservice.updateHostCapacityAndCountBed(hostRoom);
		
		String view = "";
		
		// 주소등록 성공시
		if(result > 0) {
			// 수용인원 입력 페이지로 이동한다.
			view = "host/hostamenity";
		}
		// 주소등록 실패시
		else {
			view = "";
		}
		
		return view;
	}
	
	@RequestMapping(value = "hostamenity.do", method = RequestMethod.GET)
	public String hostGetAmenity(Principal principal, boolean back) {
		return "host/hostamenity";
	}
	
	/**
	 * 편의시설 입력 페이지에서 다음 버튼 누른 후
	 * 숙소사진 업로드 전 페이지로 이동한다.
	 *  
	 * @param hostRoom
	 * @param request
	 * @return
	 */
	@RequestMapping(value = "beforeroompicture.do", method = RequestMethod.POST)
	public String beforeroompicture(HostRoom hostRoom, Principal principal) {
		
		hostRoom.setKitchen(hostRoom.getKitchen() == null ? "0" : "1");
		hostRoom.setLaundry(hostRoom.getLaundry() == null ? "0" : "1");
		hostRoom.setWifi(hostRoom.getWifi() == null ? "0" : "1");
		hostRoom.setAirconditioner(hostRoom.getAirconditioner() == null ? "0" : "1");
		hostRoom.setFree_parking(hostRoom.getFree_parking() == null ? "0" : "1");
		hostRoom.setBbq_grill(hostRoom.getBbq_grill() == null ? "0" : "1");
		hostRoom.setShower_supplies(hostRoom.getShower_supplies() == null ? "0" : "1");
		hostRoom.setCooking_item(hostRoom.getCooking_item() == null ? "0" : "1");
		hostRoom.setTv(hostRoom.getTv() == null ? "0" : "1");
		hostRoom.setOtt(hostRoom.getOtt() == null ? "0" : "1");
		hostRoom.setAvailable_smoking(hostRoom.getAvailable_smoking() == null ? "0" : "1");
		hostRoom.setAvailable_pet(hostRoom.getAvailable_pet() == null ? "0" : "1");
		
		int result = hostservice.updateOptionAmenity(hostRoom);
		
		String view = "";
		
		// 주소등록 성공시
		if(result > 0) {
			// 수용인원 입력 페이지로 이동한다.
			view = "host/beforeroompicture";
		}
		// 주소등록 실패시
		else {
			view = "";
		}
		
		return view;
	}
	
	@RequestMapping(value = "beforeroompicture.do", method = RequestMethod.GET)
	public String hostGetBeforeroompicture(Principal principal, boolean back) {
		return "host/beforeroompicture";
	}
	
	
	/**
	 
	 * 사진 업로드 후 숙소 이름 정하기 페이지로 이동한다.
	 * 
	 * @param hostRoom
	 * @return
	 */
	@RequestMapping(value = "hostroomname.do", method = RequestMethod.POST)
	public String hostroomname(HostRoom hostRoom, HttpServletRequest request, Principal principal) {
		
		Map<String, String> map = new HashMap<String, String>(); 
		
		int count = 0;
		
		for(MultipartFile file : hostRoom.getUpload_files()) {
			
			count++;
			
			map.put("file" + count, FileUtils.saveFiles(file, request));
			
		}
		
		hostservice.updateFile(map, hostRoom);
		
		return "host/hostroomname";
	}
	
	@RequestMapping(value = "hostroomname.do", method = RequestMethod.GET)
	public String hostGetHostroomname(Principal principal, boolean back) {
		return "host/hostroomname";
	}
	
	/**
	 * 호스트룸 이름 등록 후 방 정보 입력페이지로 이동한다.
	 * 
	 * @param hostRoom
	 * @return
	 */
	@RequestMapping(value = "hostroomintroduce.do", method = RequestMethod.POST)
	public String hostroomintroduce(HostRoom hostRoom, Principal principal) {
		
		int result = hostservice.updateHostRoomName(hostRoom);
		
		String view = "";
		
		if(result > 0) {
			view = "host/hostroomintroduce";
		} else {
			
		}
		
		return view;
	}
	
	// 숙소 소개
	@RequestMapping(value = "hostroomintroduce.do", method = RequestMethod.GET)
	public String hostGetRoomintroduce(Principal principal, boolean back) {
		return "host/hostroomintroduce";
	}
	
	
	
	
	// 숙소 요금
	@RequestMapping(value = "hostroomcost.do", method = RequestMethod.POST)
	public String hostroomcost(HostRoom hostRoom, Principal principal) {
		
		int result = hostservice.updateHostRoomInfo(hostRoom);
		
		String view = "";
		
		if(result > 0) {
			view = "host/hostroomcost";
		} else {
			
		}
		
		return view;
	}
	
	@RequestMapping(value = "hostroomcost.do", method = RequestMethod.GET)
	public String hostGethostRoomcost(Principal principal, boolean back) {
		return "host/hostroomcost";
	}
	
	
	// 숙소 이용 규정
	@RequestMapping(value = "hostrule.do", method = RequestMethod.POST)
	public String hostrule(HostRoom hostRoom, Principal principal) {
		
		int result = hostservice.updateHostCost(hostRoom);
		
		String view = "";
		
		if(result > 0) {
			view = "host/hostrule";
		} else {
			
		}
		
		return view;
	}
	
	
	@RequestMapping(value = "hostrule.do", method = RequestMethod.GET)
	public String hostGethostrule(Principal principal, boolean back) {
		return "host/hostrule";
	}
	
	@Autowired
	private JoinService joinservice;
	
	// 호스트 환영
	@RequestMapping("hostwelcome.do")
	public String hostwelcome(HostRoom hostRoom, Principal principal) {
		
		int result = hostservice.updateHostComplete(hostRoom);
		
		PauseMember pausemember = joinservice.getPauseMember(principal.getName());
		
		int result2 = hostservice.insertHostRole("ROLE_HOST", pausemember.getTagnumber(), pausemember.getPhone_number());
		
		String view = "";
		
		if(result > 0 && result2 > 0) {
			view = "host/hostwelcome";
		} else {
			
		}
		
		return view;
	}
}








