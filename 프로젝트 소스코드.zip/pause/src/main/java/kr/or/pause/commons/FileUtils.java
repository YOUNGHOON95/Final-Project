package kr.or.pause.commons;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

@Component
public class FileUtils {
	
	public static String saveFiles(MultipartFile uploadFile, HttpServletRequest request) {
		UUID uuid = UUID.randomUUID();
		
		String filename = uuid + "_" + uploadFile.getOriginalFilename();
		
		String filepath = request.getSession().getServletContext().getRealPath("upload");
		
		// 저장할 File 객체를 생성(껍데기 파일)ㄴ
	    File saveFile = new File(filepath, filename); 

	    try {
	    	uploadFile.transferTo(saveFile); // 업로드 파일에 saveFile이라는 껍데기 입힘
	    } catch (IOException e) {
	        e.printStackTrace();
	        return null;
	    }
		
		return filename;
	}
	
}
