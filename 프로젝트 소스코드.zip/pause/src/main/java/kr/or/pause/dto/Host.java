package kr.or.pause.dto;

import lombok.Data;

@Data
public class Host {
	private int host_no;
	private int tagnumber;
	private String auth_identification;
	// TODO 사진
	private long income;
}
