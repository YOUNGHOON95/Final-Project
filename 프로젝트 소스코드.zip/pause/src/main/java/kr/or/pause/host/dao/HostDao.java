package kr.or.pause.host.dao;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import kr.or.pause.dto.HostBookingPage;
import kr.or.pause.dto.HostReview;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import kr.or.pause.dto.Chat;
import kr.or.pause.dto.Host;
import kr.or.pause.dto.HostRoom;
import kr.or.pause.dto.PauseHost;

public interface HostDao {

	Host selectHost(int tagnumber);

	HostRoom selectHostRoom(Host host);

	HostRoom selectSavedHostRoom(Host host);

	HostRoom selectroomname(int no);
	
	@Select(" select tagNumber from member where phone_number = #{phone_number} ")
	String getTagNumber(String phone_number);

	@Select(" SELECT COUNT(*) FROM OPTION_AMENITY WHERE NO = #{no} ")
	int selectOptionAmenity(HostRoom hostRoom);

	// 제일 시작 단계 (1)
	@Insert(" INSERT INTO HOST( HOST_NO, TAGNUMBER ) VALUES( HOST_SEQ.NEXTVAL, #{tagnumber} ) ")
	int insertHostRegister(int tagnumber);

	// 제일 시작 단계 (1)
	@Insert(" INSERT INTO HOST_ROOM(NO, HOST_NO, STATUS) VALUES(HOST_ROOM_SEQ.NEXTVAL, #{host_no}, '1' ) ")
	int insertHostRoomRegister(int host_no);

	// 위치 정보 등록 (2)
	@Update(" UPDATE HOST_ROOM SET ZIP_CODE = #{zip_code}, ADDR = #{addr}, ADDR_DETAIL = #{addr_detail}, STATUS = '2' WHERE NO = #{no} ")
	int updateHostLocation(HostRoom hostRoom);

	// 인원 및 침대 수 등록 (3)
	@Update(" UPDATE HOST_ROOM SET CAPACITY = #{capacity}, STATUS = '3' WHERE NO = #{no} ")
	int updateHostCapacity(HostRoom hostRoom);

	// 인원 및 침대 수 등록 (3)
	@Insert(" INSERT INTO OPTION_AMENITY(NO, COUNT_BED) VALUES(#{no}, #{count_bed}) ")
	int insertOptionAmenity(HostRoom hostRoom);

	// 인원 및 침대 수 등록 (3)
	@Update(" UPDATE OPTION_AMENITY SET COUNT_BED = #{count_bed} WHERE NO = #{no} ")
	int updateHostCountBed(HostRoom hostRoom);

	// 편의시설 등록 (4)
	int updateOptionAmenity(HostRoom hostRoom);

	// 사진 업로드 (5)
	int updateFile(@Param("map") Map<String, String> map, @Param("hostRoom") HostRoom hostroom);
	
	// 사진 수정
	int updateFile2(@Param("map") Map<String, String> map, @Param("hostRoom") HostRoom hostroom);

	// hostroom 이름 등록 (6)
	@Update(" UPDATE HOST_ROOM SET NAME = #{name}, STATUS = '6' WHERE NO = #{no} ")
	int updateHostRoomName(HostRoom hostRoom);

	// hostroom 정보 등록(7)
	@Update(" UPDATE HOST_ROOM SET INFO = #{info}, STATUS = '7' WHERE NO = #{no} ")
	int updateHostRoomInfo(HostRoom hostRoom);

	// hostroom cost 등록(8)
	@Update(" UPDATE HOST_ROOM SET COST = #{cost}, STATUS = '8' WHERE NO = #{no} ")
	int updateHostCost(HostRoom hostRoom);

	// hostroom 등록 완료(9)
	@Update(" UPDATE HOST_ROOM SET STATUS = '9' WHERE NO = #{no} ")
	int updateHostComplete(HostRoom hostRoom);

	// 숙소 이름 가져오기
	@Select("SELECT COUNT(*) FROM HOST_ROOM WHERE NAME = #{name}")
	int roomname(HostRoom hostRoom);
	
	// 2021 / 06 / 17 김대업 (호스트 정보 불러오기)
	@Select(" SELECT * FROM HOST WHERE TAGNUMBER = #{tagnumber}")
	public PauseHost getPauseHost(int tagnumber);
	
	// 호스트 예약 내역 조회 (승인 / 거절)
	public List<HostBookingPage> hostbookinglist(int host_no , int status);
	
	// 호스트가 승인을 누르면 Status 컬럼 업데이트 
	@Update("UPDATE BOOKING SET STATUS = 2 WHERE BOOKING_NO = #{booking_no}")
	boolean updateStatus(int booking_no);
	
		
	// 호스트가 거절을 누르면 Status 컬럼 업데이트
	@Update("UPDATE BOOKING SET STATUS = 3 WHERE BOOKING_NO = #{booking_no}")
	boolean rejectBooking(int booking_no);
	
	// 다른 호스트들이 작성한 고객 리뷰
	@Select("SELECT * FROM HOST_REVIEW WHERE TAGNUMBER = #{tagnumber}")
	List<HostReview> hostReviewlist(int tagnumber);
	
	
	List<HostRoom> selectListHostRoom(@Param("host") Host host,@Param("start") int start,@Param("end") int end);
	
	int updateHostRoomDynamic(HostRoom hostRoom);
	
	List<Map<String, String>> getMessageNav(String guest_tagnumber);
	
	@Select(" select * from v_host_guest_booking v where v.booking_no = #{booking_no} ")
	Map<String, String> getDetail(Chat chat);
	
	@Select(" select count(*) from chat where to_user = #{to_user} and m_check = 0 ")
	int getCount(Chat chat);
	
	@Select(" select msg, from_user, to_user, m_check, to_char(write_date, 'HH24:MI') as write_date, write_date as orderdate from chat where booking_no = #{booking_no} order by orderdate ")
	List<Chat> getMessageInteract(Chat chat);
	
	@Insert(" insert into chat(msg, to_user, from_user, booking_no) values(#{msg}, #{to_user}, #{from_user}, #{booking_no}) ")
	int insertChat(Chat chat);

	
	@Insert( "INSERT INTO USER_ROLE VALUES( #{role_name}, #{tagnumber}, #{phone_number} )" )
	int insertHostRole(@Param("role_name") String role_name, @Param("tagnumber") int tagnumber, @Param("phone_number") String phone_number);
	
	@Update(" UPDATE CHAT SET M_CHECK = 1 WHERE TO_USER = #{from_user} AND BOOKING_NO = #{booking_no} ")
	int updatemessageconfirm(Chat chat);
	
}
