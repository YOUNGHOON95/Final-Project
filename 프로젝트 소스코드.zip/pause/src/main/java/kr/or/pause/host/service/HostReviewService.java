package kr.or.pause.host.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.or.pause.booking.dao.BookingDao;
import kr.or.pause.dto.Booking;
import kr.or.pause.dto.HostReviewForHost;
import kr.or.pause.dto.Host_review;
import kr.or.pause.host.dao.HostReviewForHostDao;

@Service
public class HostReviewService {

	@Autowired
	private SqlSession sqlsession;

	public ArrayList<HostReviewForHost> getList(int host_no) throws ClassNotFoundException, SQLException {
		ArrayList<HostReviewForHost> list = new ArrayList<HostReviewForHost>();
		HostReviewForHostDao hostReviewForHostDao = sqlsession.getMapper(HostReviewForHostDao.class);
		list = hostReviewForHostDao.getList(host_no);
		return list;
	}

}