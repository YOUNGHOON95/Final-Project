package kr.or.pause.dto;

import lombok.Data;

@Data
public class Host_review {
	private int booking_no;
	private int tagnumber;
	private int avg;
	private String content;
	
	public Host_review(int booking_no, int tagnumber, int avg, String content) {
		super();
		this.booking_no = booking_no;
		this.tagnumber = tagnumber;
		this.avg = avg;
		this.content = content;
	}
	
}
