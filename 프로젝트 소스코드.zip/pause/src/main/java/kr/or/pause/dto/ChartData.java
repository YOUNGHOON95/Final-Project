package kr.or.pause.dto;


import lombok.Data;

@Data
public class ChartData {
	int room_no;
	int income;
	int bk_count;
	int host_no;
	String room_name;
	String month;
}
