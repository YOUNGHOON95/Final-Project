package kr.or.pause.dto;

import lombok.Data;

@Data
public class SearchCardAjax {
	private String capacity;
	private String check_in;
	private String check_out;
	private String addr;
}
