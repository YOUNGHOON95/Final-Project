package kr.or.pause.dto;

import lombok.Data;

@Data
public class SearchCard {
	private String name;
	private int capacity;
	private String file1;
	private int cost;
	private int no;
	private long total_avg;
	private int cnt;
	private int count_bed;
}
