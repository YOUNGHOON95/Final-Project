package kr.or.pause.booking.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.or.pause.booking.dao.BookingDao;
import kr.or.pause.dto.Booking;
import kr.or.pause.dto.ChartData;
import kr.or.pause.dto.Host_review;

@Service
public class BookingService {
	
	@Autowired
	private SqlSession sqlsession;
	
	public ArrayList<Booking> getBooking(int host_no) throws ClassNotFoundException, SQLException{
		ArrayList<Booking> list = new ArrayList<Booking>();
		BookingDao bookingDao = sqlsession.getMapper(BookingDao.class);
		list = bookingDao.getBooking(host_no);
		return list;
	}
	
	public int insertHostReview(int booking_no, int tagnumber, int avg, String content) throws ClassNotFoundException, SQLException{
		Host_review hr = new Host_review(booking_no, tagnumber, avg, content);
		int result;
		int result2;
		BookingDao bookingDao = sqlsession.getMapper(BookingDao.class);
		result = bookingDao.insertHost_review(hr);
		result2 = bookingDao.updateHost_review(hr);
		System.out.println(result);
		System.out.println(result2);
		return result;
	}
	
	public ArrayList<ChartData> getChart(int host_no) throws ClassNotFoundException, SQLException{
		ArrayList<ChartData> list = new ArrayList<ChartData>();
		BookingDao bookingDao = sqlsession.getMapper(BookingDao.class);
		list = bookingDao.getChart(host_no);
		return list;
	}
}