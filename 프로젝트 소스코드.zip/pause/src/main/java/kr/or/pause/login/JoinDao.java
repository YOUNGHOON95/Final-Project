package kr.or.pause.login;


import java.util.List;

import org.apache.ibatis.annotations.Param;

import kr.or.pause.dto.CustomerReview;
import kr.or.pause.dto.MemberBooking;
import kr.or.pause.dto.PauseMember;

public interface JoinDao {
	
	// 사이트 자체 회원 가입 
	public void insert(PauseMember member);
	
	// 중복된 휴대폰 번호 막기
	public int phoneCheck(String phone_number);
	
	// 회원 정보 불러오기
	public PauseMember getPauseMember(String phone_number);
	
	// 회원 정보 수정하기
	public void updateName (PauseMember member);
	 
	// 회원 예약 내역 조회 
	public List<MemberBooking> bookinglist(Integer tagnumber , Integer status);
	
	// 회원 리뷰 작성
	public void insertReview(CustomerReview customerreview);
	
	// 회원 리뷰 작성시 STATUS = 6 으로 업데이트 
	public void updateReviewReservation(Integer booking_no);
		
	// 예약 테이블 취소 사유 컬럼 업데이트 / status = 3으로 업데이트 
	public int updateCancelReason(@Param("cancelcontent") String cancelcontent , @Param("booking_no") Integer booking_no );
	
	public int updateCancelStatus(Integer booking_no);
	
	// 결제여부 payment
	public void updatePayment(Integer booking_no);
	
	// 결제완료 예약
	public void updateStatusbook(Integer booking_no);
	
}
