package kr.or.pause.dto;

import lombok.Data;

@Data
public class DetailCusReview {
	private String write_date;
	private String content;
	private String profile_img;
	private String name;
	private int avg;
	
}
